<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//define("TABLE_PREFIX", "sigesfs_");
define("CONFIG_EMAIL_SUPPORT", "support@uy2com");
define("CONFIG_DU", "1");
define("CONFIG_DP", "2");
define("CONFIG_FM", "3");
define("CONFIG_SIGNATURE_SIGES", "
  <p><br />
  ____________________________________<BR />
  UYII ONLINE &copy; 2017 <br />
  ".CONFIG_EMAIL_SUPPORT."
  </p>
");
define("CONFIG_SMTPHOST", "smtp.gmail.com");
define("CONFIG_SMTPUSER", "siges.online@gmail.com");
define("CONFIG_SMTPPASS", "@SigesOnline");
define("CONFIG_SMTPUSERNAME", "Administrateur Siges-Online");
define("FTP_SERVER", "ftp.univ-dschang.org");
define("FTP_USER", "univdsch");
define("FTP_PASS", "@dsAdminWeb1");
define("DIR_DIST", "CSV");
define("DIR_DIST_NEW", "CSV/CSV_OLD");
define("DIR_LOCAL", "csv");

define("DIR_PIC","D:\PROJETS\CARTE_ETUDIANT_2017\DB\PHOTOS");


?>
