<?php

class AuthController extends Zend_Controller_Action {

    public function init() {
        $mysession = new Zend_Session_Namespace('mysession');
        $mysession->menu = "auth";
        parent::init();
    }

    public function indexAction() {
        // action body
    }

    function logoutAction() {
        Zend_Auth::getInstance()->clearIdentity();
        Zend_Session::destroy();
//        $tableCpt = new Application_Model_DbTable_Cptconnectes();
//        $data = array(
//            'time' => time(),
//            'member' => '0'
//        );
        //$tableCpt->update($data, array('ip = ?' => $_SERVER['REMOTE_ADDR']));
        $this->_redirect('/');
    }

    public function loginAction() {
        // action body
        $front = Zend_Layout::getMvcInstance();
        $front->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        $mysession = new Zend_Session_Namespace('mysession');

        // CrÃ©e une connexion de base de donnÃ©es SQLite en mÃ©moire
        $login = $this->_request->getParam("login");
        $passwd = $this->_request->getParam("passwd");

        $db = $this->_getParam('db');

        $usersDBTable = new Application_Model_DbTable_Users();
        $tableName = $usersDBTable->getName();

        $adapter = new Zend_Auth_Adapter_DbTable(
                $db, $tableName, 'login', 'passwd', 'MD5(CONCAT(?, passwd_salt))'
        );

        $adapter->setIdentity($login);
        $adapter->setCredential($passwd);

        //$result = $adapter->authenticate($adapter);
        $result = $adapter->authenticate();

        if ($result->isValid()) {
            //$this->_helper->FlashMessenger('Successful Login');
            echo "Successful login!!! Please wait ...";

            $data = $adapter->getResultRowObject(NULL, "passwd");
            $auth = Zend_Auth::getInstance();
            $auth->getStorage()->write($data);



            $tableUsers = new Application_Model_DbTable_Users();
            $users = $tableUsers->fetchAll("login='$login'", NULL, "1");

            $user = array();
            $user['id'] = $users[0]->id;
            $user['fullname'] = $users[0]->fullname;
            $user['login'] = $login;
            $user['gid'] = $users[0]->gid;
            $idgroup = $users[0]->gid;
            $mysession->user = $user;

            /**
             * Chargement du menu de l'user
             */
            $db = Zend_Db_Table_Abstract::getDefaultAdapter();
            $db->setFetchMode(Zend_Db::FETCH_OBJ);

            $sql = "SELECT M.id,M.codemenu,M.idparent,M.idcontroller,M.idaction,M.isparent,
                M.niveau,M.libelle_fr,M.controllername,M.actionname,M.description
                FROM menus M
                JOIN menugroup MG ON M.id=MG.idmenu
                WHERE MG.idgroup='$idgroup' AND active=1
                ";

            //echo $sql;
            $menu = $db->fetchAll($sql);
            $mysession->tabMenu = $menu;

            /**
             * Update cptconnected
             */
            $tableCpt = new Application_Model_DbTable_Cptconnectes();
            $data = array(
                'time' => time(),
                'member' => '1'
            );
            $tableCpt->update($data, array('ip = ?' => $_SERVER['REMOTE_ADDR'], 'session_id = ?' => Zend_Session::getId()));

            $date = date('d/m/Y');
            $heure = date('H:i:s');
            $last_login = $date . ", " . $heure;
            $mysession->user['last_login'] = $last_login;
            $tableUsers = new Application_Model_DbTable_Users();
            $dataLastConnect = array(
                'last_login' => $last_login
            );

            $tableUsers->update($dataLastConnect, array('id=?' => $users[0]->id));


            /**
             * On récupére l'établissement de l'étudiant
             */
            if ($users[0]->gid == 2) {
//                    $db = Zend_Db_Table::getDefaultAdapter();
//                    $db->setFetchMode(Zend_Db::FETCH_OBJ);
//                    $sql = "SELECT E.nometablissement_fr,E.nometablissement_en,E.id 
//                        FROM etablissements E WHERE  E.`code`='".$users[0]->fac."' LIMIT 1";
//                    $etabEtud = $db->fetchAll($sql);
//                    $mysession->user['etab'] = $etabEtud[0];

                /**
                 * On récupére les infos perso de l'étudiant
                 */
//                    $tablePrefix = "siges" . $users[0]->fac . "_";
//                    $sql = "SELECT DATE_FORMAT(E.datenaissetud,'%d/%m/%Y') AS datenaissetud,E.emailetud,E.lieuNaissance 
//                            FROM ".$tablePrefix."etudiant E
//                            WHERE E.idUtilisateur = '{$users[0]->id}' LIMIT 1";
//                    $infosEtud = $db->fetchAll($sql);
//                    $mysession->user['infospersoetud'] = $infosEtud[0];
            }
        } else {
            //echo "FAILURE";
            $message = "";
            switch ($result->getCode()) {
                case Zend_Auth_Result::FAILURE_IDENTITY_NOT_FOUND:
                    /** l'identifiant n'existe pas * */
                    $message = "Cet identifiant n'existe pas";
                    break;

                case Zend_Auth_Result::FAILURE_CREDENTIAL_INVALID:
                    /** mauvaise authentification * */
                    $message = "Mauvaise authentification";
                    break;

                case Zend_Auth_Result::SUCCESS:
                    /** authentification acceptÃ©e * */
                    break;
            }
            echo $message;
        }
    }

    public function loginformAction() {
        // action body
        $mysession = new Zend_Session_Namespace('mysession');
        $front = Zend_Layout::getMvcInstance();
        $front->disableLayout();

        if (isset($_POST['formlogin'])) {


            $mysession = new Zend_Session_Namespace('mysession');

            $login = "";
            $passwd = "";

            if (isset($_POST["formlogin"]) and isset($_POST["formpasswd"])) {
                //$login = mysql_real_escape_string ($_POST['formlogin']);
                //$passwd = mysql_real_escape_string ($_POST['formpasswd']);
                $login = $_POST['formlogin'];
                $passwd = $_POST['formpasswd'];
            } else {
                $login = $this->_request->getParam("login");
                $passwd = $this->_request->getParam("passwd");
            }

            $login = preg_replace("/[^a-zA-Z0-9]+/", "", $login);
            $passwd = preg_replace("/[^a-zA-Z0-9]+/", "", $passwd);




            $db = $this->_getParam('db');
            //$facPrefix = $mysession->facPrefix;
            //$tablePrefix = 'siges' . $facPrefix . '_';
            //$tableUsers = $tablePrefix . "users";

            $usersDBTable = new Application_Model_DbTable_Users();
            $tableName = $usersDBTable->getName();

            $adapter = new Zend_Auth_Adapter_DbTable(
                    $db, $tableName, 'login', 'passwd', 'MD5(CONCAT(?, passwd_salt))'
            );

            $adapter->setIdentity($login);
            $adapter->setCredential($passwd);

            //$result = $adapter->authenticate($adapter);
            $result = $adapter->authenticate();

            if ($result->isValid()) {
                //$this->_helper->FlashMessenger('Successful Login');
                //echo "Successful login!!! Please wait ...";

                $data = $adapter->getResultRowObject(NULL, "passwd");
                $auth = Zend_Auth::getInstance();
                $auth->getStorage()->write($data);

                $db = Zend_Db_Table_Abstract::getDefaultAdapter();
                $db->setFetchMode(Zend_Db::FETCH_OBJ);

                $users = $db->fetchAll("SELECT * FROM users WHERE login='$login' LIMIT 1");

                $tablePrefix = "siges" . $users[0]->fac . "_";
                $mysession->user = $users[0];
                $idUser = $users[0]->id;
                $sqlSelectEtud = "SELECT E.id, E.matriculeetud,E.nometud,E.prenometud,E.datenaissetud,E.lieuNaissance "
                        . "FROM {$tablePrefix}etudiants E WHERE idUtilisateur='$idUser' LIMIT 1 ";
                //echo $sqlSelectEtud;
                //die();
                $etud = $db->fetchAll($sqlSelectEtud);
                $mysession->etud = $etud[0];
                $faculte = $db->fetchAll("SELECT nometablissement_en, nometablissement_fr FROM etablissements WHERE code='{$mysession->user->fac}'");
                $mysession->faculte = $faculte[0];
                /**
                 * Update cptconnected
                 */
                $this->view->forward = 'yes';
                if(count($etud) == 0) {
                     $this->view->file = 'no';
                }
                else
                    $this->view->file = 'yes';
            } else {
                //echo "FAILURE";
                $message = "";
                switch ($result->getCode()) {
                    case Zend_Auth_Result::FAILURE_IDENTITY_NOT_FOUND:
                        /** l'identifiant n'existe pas * */
                        $message = "NOM D'UTILISATEUR OU MOT DE PASSE INCORRECT";
                        break;

                    case Zend_Auth_Result::FAILURE_CREDENTIAL_INVALID:
                        /** mauvaise authentification * */
                        $message = "NOM D'UTILISATEUR OU MOT DE PASSE INCORRECT";
                        break;

                    case Zend_Auth_Result::SUCCESS:
                        /** authentification acceptÃ©e * */
                        break;
                }
                $this->view->error = $message;
            }
        }
    }

}
