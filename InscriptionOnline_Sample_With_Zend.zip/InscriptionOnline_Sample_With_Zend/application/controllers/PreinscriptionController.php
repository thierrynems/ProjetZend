<?php

require_once 'BaseController.php';

class PreinscriptionController extends BaseController {

    public function init() {
        $mysession = new Zend_Session_Namespace('mysession');
        $mysession->menu = "preins";
        parent::init();
    }

    public function indexAction() {
        $mysession = new Zend_Session_Namespace('mysession');
        $db = Zend_Db_Table::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);
        $this->view->ListEtabs = $db->fetchAll("SELECT * FROM etablissements");
    }

    public function nouveauAction() {
        $mysession = new Zend_Session_Namespace('mysession');
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);
        $idEtab = $this->_getParam("e");
        $etabs = $db->fetchAll("select * from etablissements WHERE id='1' LIMIT 1");
        $this->view->etab = $etabs[0];
        $prefixTable = "siges" . $etabs[0]->code . "_";
    }

    public function saveAction() {
        $infospreinscrit = new Zend_Session_Namespace('infospreinscrit');
        $mysession = new Zend_Session_Namespace('mysession');

        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        $tablePrefix = "siges" . $_POST['codeetab'] . "_";

        if (isset($_POST['diplomeadmission']) and isset($_POST['nometud'])) {

            $nometud = addslashes(str_replace("  ", " ", trim($this->_getParam("nometud"))));
            $prenometud = addslashes(str_replace("  ", " ", trim($this->_getParam("prenometud"))));
            for ($i = 0; $i <= 3; $i++) {
                $nometud = str_replace("  ", " ", trim($nometud));
                $prenometud = str_replace("  ", " ", trim($prenometud));
            }
            $classelmd = $_POST['classelmd'];
            $typeformation = $_POST['typeformation'];
            $dateNaiss = $_POST['anneeNaiss'] . "-" . $_POST['moisNaiss'] . "-" . $_POST['jourNaiss'];
            $lieudenaiss = addslashes(str_replace("  ", " ", trim($this->_getParam("lieuNaissance"))));

            $requeVerif = "SELECT E.id,E.idUtilisateur,E.sexeetud,E.lieuNaissance, P.id AS numdossier FROM " . $tablePrefix . "etudiant E "
                    . "JOIN " . $tablePrefix . "preinscription P ON P.idetudiant=E.id  "
                    . "WHERE E.nometud='$nometud' AND E.prenometud='$prenometud' AND E.datenaissetud='$dateNaiss' "
                    . "AND (P.idconcours IS NULL OR P.idconcours=0) AND P.idclasse='$classelmd' AND P.idtypeformation='$typeformation' "
                    . "AND P.idanneeacademique=(SELECT id FROM " . $tablePrefix . "anneeacademique WHERE encours=1)";

            //echo $requeVerif;
            $verifEtud = $db->fetchAll($requeVerif);
            //echo $classelmd;

            $sqlClasslmd = "SELECT code FROM " . $tablePrefix . "classelmd WHERE id='$classelmd' LIMIT 1";
            $classes = $db->fetchAll($sqlClasslmd);
            $codeClasse = $classes[0]->code;

            //echo substr($codeClasse,0,1);

            if (count($verifEtud) != 0 and ( substr($codeClasse, 0, 1) == 'L' or substr($codeClasse, 0, 1) == 'C')) {
                $this->view->doublon = 1;
                $this->view->etudDouble = $verifEtud[0];
            } else {

                $tablePrefix = "siges" . $_POST['codeetab'] . "_";
                //else {
                $this->view->doublon = 0;
                ///////////////////////////////////////////////////////////////////////////////////////////

                /* @var $idregion type */
                $idregion = filter_input(INPUT_POST, 'RegionOrigine', FILTER_SANITIZE_NUMBER_INT);
                $regionEtud = $db->fetchAll("SELECT libelle_fr,libelle_en FROM " . $tablePrefix . "region WHERE id='$idregion' LIMIT 1");
                $libelleRegionOrigine = $regionEtud[0]->libelle_fr;

                $iddept = $_POST['DeptOrigine'];
                $deptEtud = $db->fetchAll("SELECT libelle_fr,libelle_en FROM " . $tablePrefix . "departementgeo WHERE id='$iddept' LIMIT 1");
                $libelleDeptOrigine = $deptEtud[0]->libelle_fr;

                $idArr = $_POST['ArrondisOrigine'];
                $arrEtud = $db->fetchAll("SELECT libelle_fr,libelle_en FROM " . $tablePrefix . "ville WHERE id='$idArr' LIMIT 1");
                $libelleArrOrigine = $arrEtud[0]->libelle_fr;

                $idmodeAdmission = $_POST['idmodeAdmission'];
                $modeAdmissionEtud = $db->fetchAll("SELECT * FROM liste_modeadmission WHERE id='$idmodeAdmission' LIMIT 1");
                $libelleModeAdmission = $modeAdmissionEtud[0]->libelle_fr;

                $diplomeadmission = $_POST['diplomeadmission'];
                $da = $db->fetchAll("SELECT libelle_fr FROM " . $tablePrefix . "diplomeadmission WHERE id='$diplomeadmission' LIMIT 1");
                $libelleDiplomeAdmin = $da[0]->libelle_fr;

                $etudObject = new Application_Model_Etudiants();

                $nometud = addslashes(str_replace("  ", " ", trim($_POST['nometud'])));
                $prenometud = addslashes(str_replace("  ", " ", trim($_POST['prenometud'])));
                for ($i = 0; $i <= 3; $i++) {
                    $nometud = str_replace("  ", " ", trim($nometud));
                    $prenometud = str_replace("  ", " ", trim($prenometud));
                }

                $etudObject->setNometud(trim($nometud));
                $etudObject->setPrenometud(trim($prenometud));

                $dateNaiss = $_POST['anneeNaiss'] . "-" . $_POST['moisNaiss'] . "-" . $_POST['jourNaiss'];
                //$tabDate = explode("/", $dateNaiss);
                //$dateNaiss = $tabDate[2] . "-" . $tabDate[1] . "-" . $tabDate[0];
                $lieudenaiss = addslashes(str_replace("  ", " ", trim($this->_getParam("lieuNaissance"))));

                $etudObject->setDatenaiss(trim($dateNaiss));
                $etudObject->setLieunaiss(ucfirst($lieudenaiss));

                $etudObject->setRegionOrigine(trim($_POST['RegionOrigine']));
                $etudObject->setPremlangofficieletud(trim($_POST['premlangofficieletud']));
                $etudObject->setDeptOrigine(trim($_POST['DeptOrigine']));
                $etudObject->setArrondisOrigine(trim($_POST['ArrondisOrigine']));

                $etudObject->setCivilite(trim($_POST['sexeetud']));
                $etudObject->setCnietud(trim($_POST['cnietud']));
                $etudObject->setSexeetud(trim($_POST['sexeetud']));
                $etudObject->setNationaliteetud(trim($_POST['nationaliteetud']));
                $etudObject->setSituationfamilialetud(trim($_POST['situationfamilialetud']));
                $etudObject->setNbreenfantetud(trim($_POST['nbreenfantetud']));
                $etudObject->setSituationemploietud(trim($_POST['situationemploietud']));
                $etudObject->setHandicape(trim($_POST['handicape']));

                $etudObject->setVilleresidenceetudiant(ucfirst(trim($_POST['villeresidenceetudiant'])));
                $etudObject->setCodeposte(trim($_POST['codeposte']));
                $etudObject->setTelephone(trim($_POST['telephone']));
                $etudObject->setFax(trim($_POST['fax']));
                $etudObject->setEmailetud(trim($_POST['emailetud']));
                $etudObject->setLibelleadresse(ucfirst(trim($_POST['libelleadresse'])));

                $etudObject->setDiplomeadmission($diplomeadmission);
                $etudObject->setAnneeobtensiondiplome(trim($_POST['anneeobtensiondiplome']));
                $etudObject->setNotediplomeetud(trim($_POST['notediplomeetud']));
                $etudObject->setLieuobtention(ucfirst(trim($_POST['lieuobtension'])));

                $etudObject->setMentiondiplome(trim($_POST['notediplomeetud']));

                $etudObject->setMentiondiplome('0');

                $etudObject->setIdmodeadmission($idmodeAdmission);
                $etudObject->setDateinscription(date("Y-m-d"));

                $etudObject->setNompere(ucwords(trim($_POST['nompere'])));
                $etudObject->setProfessionpere(trim($_POST['professionpere']));
                $etudObject->setNommere(ucwords(trim($_POST['nommere'])));
                $etudObject->setProfessionmere(trim($_POST['professionmere']));
                $etudObject->setCodeposteparent(trim($_POST['codeposteparent']));
                $etudObject->setFaxparent(trim($_POST['faxparent']));
                $etudObject->setTelephoneparent(trim($_POST['telephoneparent']));
                $etudObject->setLieuderesidenceparent(ucfirst(trim($_POST['lieuderesidenceparent'])));
                $etudObject->setAdresseparent(trim($_POST['adresseparent']));

                //$etudMapper = new Application_Model_EtudiantsMapper();
                //$etudMapper->save($etudObject);
                //ancienid,anneeobtensiondiplome,dateinscription,datenaissetud,diplomeadmission,idmodeAdmission,lieuobtension,mentiondiplome,nationaliteetud,nometud,notediplomeetud,premlangofficieletud,sexeetud,villeresidenceetudiant

                /**
                 * Création du compte user
                 */
                //Génération du login user et mot de passe (login à 10chiffres et mdp à 6 chiffres)
                $modelUsers = new Application_Model_DbTable_Users();
                //substr(date("Y"), 2,2) .
                $loginPrefix = date("m");
                $login = "";
                $rand = "";
                $tab = array("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z");
                do {
                    $rand = rand(1, 99999);
                    $login = $tab[rand(0, 25)] . $loginPrefix . $rand;
                    //$users = $modelUsers->fetchAll("login='$login'", null, "1");
                    $users = $db->fetchAll("SELECT * FROM users WHERE login='$login'");
                } while (count($users) > 0);

                $passwd_salt = $rand;

                $textPasswd = "";
                do {
                    $rand = rand(0, 9);
                    $textPasswd .= $rand;
                } while (strlen($textPasswd) < 6);

                $infospreinscrit->login = $login;
                $infospreinscrit->login = $textPasswd;

                $dataUser = array(
                    "login" => $login,
                    "passwd" => md5($textPasswd . $passwd_salt),
                    "passwd_salt" => $passwd_salt,
                    "nomComplet" => trim($_POST['nometud']) . " " . trim($_POST['prenometud']),
                    "idGroup" => 2,
                    "fac" => $_POST['codeetab'],
                    "active" => 1,
                    "last_login" => "",
                    "isOld" => 0,
                    "isUpdate" => 1
                );

                $userObj = new Application_Model_Users();
                $userObj->setLogin($login);
                $userObj->setPasswd(md5($textPasswd . $passwd_salt));
                $userObj->setPasswd_salt($passwd_salt);
                $userObj->setNomcomplet(trim($_POST['nometud']) . " " . trim($_POST['prenometud']));
                $userObj->setIdgroup('2');
                $fac = $_POST['codeetab'];
                $userObj->setFac($fac);
                $userObj->setActive('1');
                $userObj->setIsOld(0);

                $usersMapper = new Application_Model_UsersMapper();
                $usersMapper->save($userObj);

                /**
                 * Recupération de l'id user
                 */
                $users = $modelUsers->fetchAll("login='$login'", "id asc", "1");
                $idUser = $users[0]->id;

                $passwd_secours = rand(1000, 9999);

                //MAJ isupdate à 1
                //$db->query("UPDATE users SET isupdate=1 WHERE id='$idUser' LIMIT 1");
                $db->query("UPDATE users SET isupdate=1,passwd_secours='$passwd_secours' WHERE id='$idUser' LIMIT 1");


                /*
                 * Envoi du POST à FM/MTN
                 */
                $faculte = $fac;
                $tab = array("sci" => "FS", "seg" => "FSEG", "asa" => "FASA", "fsh" => "FLSH", "sjp" => "FSJP", "iut" => "IUT-FV", "iba" => "IBAF");
                $faculte = $tab[$faculte];
                $NomComplet = trim($_POST['prenometud']) . " " . trim($_POST['nometud']);
                commonClass::sendPasswdSecoursToMTN($idUser, $NomComplet, $login, $passwd_secours, $faculte);

                $this->view->username = $login;
                $this->view->passwd = $textPasswd;

                $mysession->username = $login;
                $mysession->passwd = $textPasswd;


                $data = array(
                    'idUtilisateur' => $idUser,
                    'idadresse' => '',
                    'idparent' => '',
                    'idville' => $etudObject->getArrondisOrigine(),
                    'idregion' => $etudObject->getRegionOrigine(),
                    'iddepartement' => $etudObject->getDeptOrigine(),
                    'idethnie' => '0',
                    'lieuNaissance' => $etudObject->getLieunaiss(),
                    'idmodeAdmission' => 2, //Etude de dossier
                    'codeetudiant' => '',
                    'matriculeetud' => $_POST['matriculeetud'],
                    'nometud' => $etudObject->getNometud(),
                    'prenometud' => $etudObject->getPrenometud(),
                    'datenaissetud' => $etudObject->getDatenaiss(),
                    'nationaliteetud' => $etudObject->getNationaliteetud(),
                    'sexeetud' => $etudObject->getSexeetud(),
                    'situationemploietud' => $etudObject->getSituationemploietud(),
                    'handicape' => $etudObject->getHandicape(),
                    'situationfamilialetud' => $etudObject->getSituationfamilialetud(),
                    'nbreenfantetud' => $etudObject->getNbreenfantetud(),
                    'premlangofficieletud' => $etudObject->getPremlangofficieletud(),
                    'photoetud' => '',
                    'villeresidenceetudiant' => $etudObject->getVilleresidenceetudiant(),
                    'codeposte' => $etudObject->getCodeposte(),
                    'telephone' => $etudObject->getTelephone(),
                    'fax' => $etudObject->getFax(),
                    'emailetud' => $etudObject->getEmailetud(),
                    'libelleadresse' => $etudObject->getLibelleadresse(),
                    'diplomeadmission' => $etudObject->getDiplomeadmission(),
                    'anneeobtensiondiplome' => $etudObject->getAnneeobtensiondiplome(),
                    'lieuobtension' => $_POST['lieuobtension'],
                    'mentiondiplome' => $etudObject->getMentiondiplome(),
                    'cnietud' => $etudObject->getCnietud(),
                    'dateinscription' => $etudObject->getDateinscription(),
                    'notediplomeetud' => $_POST['notediplomeetud'],
                    'typeimage' => '',
                    'numeroseriepremiereinscription' => "",
                    'civilite' => $etudObject->getCivilite(),
                    'nompere' => $etudObject->getNompere(),
                    'professionpere' => $etudObject->getProfessionpere(),
                    'nommere' => $etudObject->getNommere(),
                    'professionmere' => $etudObject->getProfessionmere(),
                    'codeposteparent' => $etudObject->getCodeposteparent(),
                    'faxparent' => $etudObject->getFaxparent(),
                    'telephoneparent' => $etudObject->getTelephoneparent(),
                    'lieuderesidenceparent' => $etudObject->getLieuderesidenceparent(),
                    'adresseparent' => $etudObject->getAdresseparent(),
                    'ancienid' => '',
                    'regionorigine' => $libelleRegionOrigine,
                    'departementorigine' => $libelleDeptOrigine,
                    'arrondissementorigine' => $libelleArrOrigine,
                    'modeadmission' => $libelleModeAdmission,
                    'sportpratique' => $_POST['sport'],
                    'autresactivites' => $_POST['autresactivites'],
                    'contact1' => $_POST['contact1'],
                    'telephone1' => $_POST['telephone1'],
                    'adresse1' => $_POST['adresse1'],
                    'contact2' => $_POST['contact2'],
                    'telephone2' => $_POST['telephone2'],
                    'adresse2' => $_POST['adresse2'],
                    'religion' => "",
                    'nomconjoint' => "",
                    'adresseconjoint' => "",
                    'datedelivrancecni' => $_POST['anneecni'] . "-" . $_POST['moiscni'] . "-" . $_POST['jourcni'],
                    'isdiplomesousreserve' => $_POST['isdiplomesousreserve'],
                    'seriediplome' => $_POST['seriediplome'],
                    'fac' => $_POST['codeetab']
                );


                $mysession->facPrefix = $_POST['codeetab'];
                $tableEtudiant = new Application_Model_DbTable_Etudiants();
                $tableEtudiant->insert($data);

                /**
                 * Enregistrement de la préinscription
                 */
                /**
                 * récupération de l'id étudiant
                 */
                $modelEtud = new Application_Model_DbTable_Etudiants();
                $student = $modelEtud->fetchAll("idUtilisateur='$idUser'", "id asc", "1");
                $idEtudiant = $student[0]->id;


                /**
                 *  Mise à jour du matricule si ancien
                 * */
//            $matricule = $_POST['matriculeetud'];
//            //echo "Le matricule est : " . $matricule;
//            $dataMatricule = array(
//                "matriculeetud" => $matricule
//            );
//            $modelEtud->update($dataMatricule, "id='$idEtudiant'");

                $idclasselmd = $_POST['classelmd'];
                $db = Zend_Db_Table_Abstract::getDefaultAdapter();

                /**
                 * recherche de la catégorie de paiement
                 */
                $idNationalite = $_POST['nationaliteetud'];
                /**
                 * $tableCatPays = new Application_Model_DbTable_Categoriepays();
                 */
                $sql = "SELECT C.idcategoriepayement FROM categoriepays C 
                WHERE C.idnationalite='$idNationalite' LIMIT 1";

                $listCatPaie = $db->fetchAll($sql);
                $idCatPaie = $listCatPaie[0]->idcategoriepayement;
                $infospreinscrit->idcatpaie = $idCatPaie;

                //sigesasa_anneeacademique
                $annees = $db->fetchAll("SELECT id FROM " . $tablePrefix . "anneeacademique WHERE encours=1");
                $idAnneeAcad = $annees[0]->id;

                $tablePreinscript = new Application_Model_DbTable_Preinscription();

                $idtypeformation = $_POST['typeformation'];

                $data = array(
                    'idetudiant' => $idEtudiant,
                    'idclasse' => $idclasselmd,
                    'idtypeformation' => $idtypeformation,
                    'idcategoriepayement' => $idCatPaie,
                    'idanneeacademique' => $idAnneeAcad,
                    'iddoplomeadmission' => $diplomeadmission,
                    'datepreinscription' => date("Y-m-d"),
                    'datevalidationpreinscription' => '',
                    'eligible' => '-1',
                    'choix1' => $_POST['option1'],
                    'choix2' => $_POST['option2'],
                    'choix3' => $_POST['option3'],
                    'exportDU' => '0',
                    'exportDP' => '0',
                    'exportFM' => '0',
                    'idcentreconcours' => '',
                    'idconcours' => '',
                    'idlieudepotdossier' => ''
                );
//idtypepreinscription,,typeadmission
//            echo "<pre>";
//            print_r($data);
//            echo "</pre>";



                $prefixTab = "siges" . $_POST['codeetab'] . "_";

                $facPrefix = $_POST['codeetab'];
                //echo "<br>prefix->" . $mysession->tablePrefix;
                $tablePreinscript = $tablePrefix . "preinscription";
                $db->insert($tablePreinscript, $data);
                //$tablePreinscript->insert($data);


                $db = Zend_Db_Table_Abstract::getDefaultAdapter();
                $db->setFetchMode(Zend_Db::FETCH_OBJ);
                /**
                 * recherche de l'id de la préinscription
                 */
                $preinsc = $db->fetchAll("SELECT P.id FROM " . $prefixTab . "preinscription P "
                        . "WHERE P.idetudiant='$idEtudiant' AND P.idanneeacademique='$idAnneeAcad' LIMIT 1");

                // echo "SELECT P.id FROM " . $prefixTab . "preinscription P WHERE P.idetudiant='$idEtudiant' AND P.idanneeacademique='$idAnneeAcad' LIMIT 1";
                $idPreinscription = $preinsc[0]->id;

                $infospreinscrit->numpreinscription = $idPreinscription;
                $this->view->idpreinscription = $infospreinscrit->numpreinscription;
                $this->view->facprefix = $facPrefix;

                //$idTypeformation = $infospreinscrit->typeformation;
                //$typeformation = $db->fetchAll("SELECT libelle_fr,libelle_en FROM " . $prefixTab . "typeformation WHERE id='$idTypeformation' LIMIT 1");
                //$infospreinscrit->libtypeformation = $concours[0]->libelle_fr;
                //echo "Libelle_type_form = " . $concours[0]->libelle_fr;

                $idclass = $_POST['classelmd'];
                $classelmd = $db->fetchAll("SELECT libelle_fr,libelle_en FROM " . $prefixTab . "classelmd WHERE id='$idclass' LIMIT 1");


                $infospreinscrit->numpreinscription = $idPreinscription;
                $this->view->idpreinscription = $infospreinscrit->numpreinscription;

                $nationalite = $db->fetchAll("SELECT libelle_fr,libelle_en FROM nationalite WHERE id='$idNationalite' LIMIT 1");
                $infospreinscrit->libnationalite = $nationalite[0]->libelle_fr;

                $modeadmin = $db->fetchAll("SELECT libelle_fr,libelle_en FROM liste_modeadmission WHERE id='$idmodeAdmission' LIMIT 1");
                $infospreinscrit->libmodeadmission = $modeadmin[0]->libelle_fr;


                /////////////////////////////////////////////////////////////////////////////////////////

                /**
                 * Chargement de la table paiePreinscription
                 */
                $idFP = CONFIG_DP;
                $idFM = CONFIG_FM;

                $idbanque = $_POST['idbanque'];
                //$tablePaiePreins = new Application_Model_DbTable_Payepreinscription();
                //$tablePrefix = $mysession->tablePrefix;
                if (!isset($idbanque))
                    $idbanque = 1;
                $dataPaie = array(
                    "idEtudiant" => $idEtudiant,
                    "idanneeacademique" => $idAnneeAcad,
                    "idtypefrais" => $idFP,
                    "idBanque" => $idbanque,
                    "nbreimpression" => 0,
                    "dategenerequitus" => date('Y-m-d'),
                    "fac" => $facPrefix
                );
                $db->insert($tablePrefix . "payepreinscription", $dataPaie);

                /**
                 * On fabrique le code de la paye 
                 */
                $paie = $db->fetchAll("SELECT P.id FROM " . $tablePrefix . "payepreinscription P
                WHERE P.idEtudiant='$idEtudiant' AND P.idanneeacademique='$idAnneeAcad' AND P.idtypefrais='$idFP' AND P.idBanque='$idbanque' 
                LIMIT 1 ");
                $idPaie = $paie[0]->id;

                //NUMETAB IDTYPEFRAIS IDPAIEINSCRIP
                $codeEtab = $_POST['codeetab'];
                $etabs = $db->fetchAll("SELECT * FROM etablissements WHERE code='$codeEtab' LIMIT 1");
                $numEtab = $etabs[0]->codenum;

                $codePaie = $numEtab . $idFP . $idPaie;
                $dataUpdatePaie = array(
                    "codepaye" => $codePaie
                );
                $where = array("id=?" => $idPaie);
                $db->update($tablePrefix . "payepreinscription", $dataUpdatePaie, $where);

                $numquitusFP = $codePaie;
                $indicePaieFP = $idEtudiant . "_" . $idPaie;
                $idtypeFrais = $idFP;

                $sqlMontant = "SELECT montant FROM " . $tablePrefix . "montanttypeformation WHERE "
                        . "idtypefrais='$idtypeFrais' AND idclasse='$idclasselmd' "
                        . "AND idcategoriepayement='$idCatPaie' AND idtypeformation='$idtypeformation' LIMIT 1 ";


                $montantReq = $db->fetchAll($sqlMontant);
                $montantFP = $montantReq[0]->montant;


                /**
                 * Frais Médicaux (FM)
                 */
                if (!isset($idbanque))
                    $idbanque = 1;
                $dataPaie = array(
                    "idEtudiant" => $idEtudiant,
                    "idanneeacademique" => $idAnneeAcad,
                    "idtypefrais" => $idFM,
                    "idBanque" => $idbanque,
                    "codepaye" => ""
                );
                $db->insert($tablePrefix . "payepreinscription", $dataPaie);

                /**
                 * On fabrique le code de la paye 
                 */
                $db = Zend_Db_Table_Abstract::getDefaultAdapter();
                $paie = $db->fetchAll("SELECT P.id FROM " . $tablePrefix . "payepreinscription P
                WHERE P.idEtudiant='$idEtudiant' AND P.idanneeacademique='$idAnneeAcad' AND P.idtypefrais='$idFM' AND P.idBanque='$idbanque' 
                LIMIT 1 ");
                $idPaie = $paie[0]->id;

                $codePaie = $numEtab . $idFM . $idPaie;

                $dataUpdate = array(
                    'codepaye' => $codePaie
                );
                $where = array("id=?" => $idPaie);
                $db->update($tablePrefix . "payepreinscription", $dataUpdatePaie, $where);

                $numquitusFM = $codePaie;
                $indicePaieFM = $idEtudiant . "_" . $idPaie;
                $idtypeFrais = $idFM;


                $sqlMontant = "SELECT montant FROM " . $tablePrefix . "montanttypeformation WHERE "
                        . "idtypefrais='$idtypeFrais' AND idclasse='$idclasselmd' "
                        . "AND idcategoriepayement='$idCatPaie' AND idtypeformation='$idtypeformation' LIMIT 1 ";


                $montantReq = $db->fetchAll($sqlMontant);
                $montantFM = $montantReq[0]->montant;


                $infospreinscrit->nometud = $_POST['nometud'];
                $infospreinscrit->prenometud = $_POST['prenometud'];
                $infospreinscrit->telephone = $_POST['telephone'];


                $facprefix = $_POST['codeetab'];

                $idpreinscription = $infospreinscrit->numpreinscription;

                $quitusPreinscription = commonClass::quitusuy($idpreinscription, $facprefix, $tablePrefix, 0);
                $nameQuitusPre = $mysession->quitusName;
                unset($mysession->quitusName);

                $quitusPreinscription = commonClass::quitusuy($idpreinscription, $facprefix, $tablePrefix, 1);
                $nameQuitusMed = $mysession->quitusName;
                unset($mysession->quitusName);


                $fichePreinscription = commonClass::fichePreinscriptionuy($idpreinscription, $tablePrefix, $facprefix);
                $nameFiche = $mysession->ficheName;
                unset($mysession->ficheName);

                $this->view->numdossier = $idpreinscription;


                $this->view->quitusPre = $nameQuitusPre;
                $this->view->quitusMed = $nameQuitusMed;
                $this->view->fichePre = $nameFiche;

                $this->view->idPreinscription = $idPreinscription;


                /**
                 * Chargement de la table paiementdatatmp
                 */
                //idpaie = idetud_idannee_idsession
                //id,url,data,method,status
                $db = Zend_Db_Table_Abstract::getDefaultAdapter();
                $db->setFetchMode(Zend_Db::FETCH_OBJ);
                $url = addslashes("http://localhost/sigesonline/public/paiements/testvalidationpaiements");
                //$url = addslashes("http://sigesonline.univ-dschang.org/paiements/testvalidationpaiements");
                //$url = addslashes("http://192.168.43.17/postuds/validate_post.php");
                //$url = addslashes("http://www.expressexchange.fr:9994/univdschang/post/");


                $data = "";
                $nom = mb_strtoupper(trim($infospreinscrit->nometud));
                $prenom = trim($infospreinscrit->prenometud);
                $telephoneEtud = trim($infospreinscrit->telephone);
                $nomComplet = $_POST['nometud'] . " " . $_POST['prenometud'];

                $sqlLib = "SELECT libelle_fr FROM " . $tablePrefix . "anneeacademique WHERE id='$idAnneeAcad' LIMIT 1";
                $annees = $db->fetchAll($sqlLib);
                $libelleAnneeAcad = $annees[0]->libelle_fr;
                $libelleAnneeAcad = str_replace('/', '-', $libelleAnneeAcad);
                $telephoneEtud = str_replace('/', '-', $telephoneEtud);
                $telephoneEtud = str_replace(' ', '', $telephoneEtud);

                $dataFM = array(
                    "numquitus" => $numquitusFM,
                    "nometudiant" => urlencode($nomComplet),
                    "montant" => $montantFM,
                    "idpaie" => $indicePaieFM,
                    "telephone" => $telephoneEtud,
                    "idetudiant" => $idEtudiant,
                    "annee" => $libelleAnneeAcad,
                    "_username" => 'univ_uy2',
                    "_pwd" => 'testdschang'
                );

                $dataFP = array(
                    "numquitus" => $numquitusFP,
                    "nometudiant" => urlencode($nomComplet),
                    "montant" => $montantFP,
                    "idpaie" => $indicePaieFP,
                    "telephone" => $telephoneEtud,
                    "idetudiant" => $idEtudiant,
                    "annee" => $libelleAnneeAcad,
                    "_username" => 'univ_uy2',
                    "_pwd" => 'testdschang'
                );

                $method = "POST";
                $arrayDataPaieFM = array(
                    "quitus" => $numquitusFM,
                    "url" => $url,
                    "data" => json_encode($dataFM),
                    "method" => $method,
                    "status" => 0,
                    "date" => date('Y-m-d')
                );

                $arrayDataPaieFP = array(
                    "quitus" => $numquitusFP,
                    "url" => $url,
                    "data" => json_encode($dataFP),
                    "method" => $method,
                    "status" => 0,
                    "date" => date('Y-m-d')
                );

                $db->insert("paymentsdatatmp", $arrayDataPaieFM);
                $db->insert("paymentsdatatmp", $arrayDataPaieFP);





                /**
                 * Chargement de la table paiementdatatmpEU
                 */
                $login = CONFIG_USER_EU;
                $ip = CONFIG_IP_EU;
                $pwd = CONFIG_USER_PASS_EU;
                $sig = CONFIG_SIG_EU;

                //Frais de preinscription

                $idpaiement = $indicePaieFP;
                $numquitus = $numquitusFP;
                $nom_etudiant = urlencode($nomComplet);
                $montant = $montantFP;
                $annee = $libelleAnneeAcad;
                $idetudiant = $idEtudiant;
                $tranche = '0';
                $type_fac = substr($numquitus, 0, 1);
                $type_paie = substr($numquitus, 1, 1);
                $urlData = CONFIG_URL_EU . "?login=" . $login . "&ip=" . $ip . "&pwd=" . $pwd . "&sig=" . $sig . ""
                        . "&idpaiement=" . $idpaiement . "&numquitus=" . $numquitus . "&nom_etudiant=" . $nom_etudiant . "&montant=" . $montant . ""
                        . "&annee=" . $annee . "&idetudiant=" . $idetudiant . "&tranche=" . $tranche . "&type_fac=" . $type_fac . "&type_paie=" . $type_paie;

                //id,quitus,url,data,method,date,status,cpteur
                $arrayDataPaieFP = array(
                    "quitus" => $numquitusFP,
                    "url" => CONFIG_URL_EU,
                    "data" => $urlData,
                    "method" => $method,
                    "status" => 0,
                    "cpteur" => 0,
                    "date" => date('Y-m-d')
                );

                $idpaiement = $indicePaieFM;
                $numquitus = $numquitusFM;
                $nom_etudiant = urlencode($nomComplet);
                $montant = $montantFM;
                $annee = $libelleAnneeAcad;
                $idetudiant = $idEtudiant;
                $tranche = '0';
                $type_fac = substr($numquitus, 0, 1);
                $type_paie = substr($numquitus, 1, 1);
                $urlData = CONFIG_URL_EU . "?login=" . $login . "&ip=" . $ip . "&pwd=" . $pwd . "&sig=" . $sig . ""
                        . "&idpaiement=" . $idpaiement . "&numquitus=" . $numquitus . "&nom_etudiant=" . $nom_etudiant . "&montant=" . $montant . ""
                        . "&annee=" . $annee . "&idetudiant=" . $idetudiant . "&tranche=" . $tranche . "&type_fac=" . $type_fac . "&type_paie=" . $type_paie;
                //id,quitus,url,data,method,date,status,cpteur
                $arrayDataPaieFM = array(
                    "quitus" => $numquitusFM,
                    "url" => CONFIG_URL_EU,
                    "data" => $urlData,
                    "method" => $method,
                    "status" => 0,
                    "cpteur" => 0,
                    "date" => date('Y-m-d')
                );

                $db->insert("paymentsdatatmpeu", $arrayDataPaieFM);
                $db->insert("paymentsdatatmpeu", $arrayDataPaieFP);



                /*                 * ******************************************************************************* */
                /**
                 * Chargement de la table paiementdatatmpMTN
                 */
                //Frais de preinscription        

                $CustomerName = urlencode($nomComplet);
                $BillReference = $libelleAnneeAcad;
                $BillNumber = $numquitusFP;
                $BillDate = date('d/m/Y');
                $annee = date('Y') + 1;
                $mois = date('m');
                $jour = date('d');
                //Date d'expiration du paiement
                //Nous mettons à l'année suivante
                $ExpiryDate = $jour . '/' . $mois . '/' . $annee;
                $CountryPhoneCode = CONFIG_COUNTRY_PHONECODE;
                $Amount = $montantFP;
                $MinimumPayment = $montantFP;
                $ExpiryPenaltyAmount = 0;
                $Currency = "XAF";
                $Informations = "";
                $PhoneNumber = commonClass::phoneValidator($telephoneEtud);
                $Published = 1;           //---0 or 1
                $OverRideDuplicate = 1;    //---0 or 1
                $urlData = "CustomerName=" . $CustomerName . "&"
                        . "BillReference=" . $BillReference . "&BillNumber=" . $BillNumber . "&BillDate=" . $BillDate . "&ExpiryDate=" . $ExpiryDate . "&"
                        . "CountryPhoneCode=" . $CountryPhoneCode . "&Amount=" . $Amount . "&MinimumPayment=" . $MinimumPayment . "&ExpiryPenaltyAmount=" . $ExpiryPenaltyAmount . "&"
                        . "Currency=" . $Currency . "&Informations=" . $Informations . "&PhoneNumber=" . $PhoneNumber . "&Published=" . $Published . "&"
                        . "OverRideDuplicate=" . $OverRideDuplicate;

                //id,quitus,url,data,method,date,status,cpteur
                $arrayDataPaieFP = array(
                    "quitus" => $numquitusFP,
                    "url" => CONFIG_URL_MTN,
                    "data" => $urlData,
                    "method" => $method,
                    "status" => 0,
                    "cpteur" => 0,
                    "date" => date('Y-m-d')
                );


                /**
                 * Frais medicaux
                 */
                $CustomerName = urlencode($nomComplet);
                $BillReference = $libelleAnneeAcad;
                $BillNumber = $numquitusFM;
                $BillDate = date('d/m/Y');
                $annee = date('Y') + 1;
                $mois = date('m');
                $jour = date('d');
                //Date d'expiration du paiement
                //Nous mettons à l'année suivante
                $ExpiryDate = $jour . '/' . $mois . '/' . $annee;
                $CountryPhoneCode = CONFIG_COUNTRY_PHONECODE;
                $Amount = $montantFM;
                $MinimumPayment = $montantFM;
                $ExpiryPenaltyAmount = 0;
                $Currency = "XAF";
                $Informations = "";
                $PhoneNumber = commonClass::phoneValidator($telephoneEtud);
                $Published = 1;           //---0 or 1
                $OverRideDuplicate = 1;    //---0 or 1
                $urlData = "CustomerName=" . $CustomerName . "&"
                        . "BillReference=" . $BillReference . "&BillNumber=" . $BillNumber . "&BillDate=" . $BillDate . "&ExpiryDate=" . $ExpiryDate . "&"
                        . "CountryPhoneCode=" . $CountryPhoneCode . "&Amount=" . $Amount . "&MinimumPayment=" . $MinimumPayment . "&ExpiryPenaltyAmount=" . $ExpiryPenaltyAmount . "&"
                        . "Currency=" . $Currency . "&Informations=" . $Informations . "&PhoneNumber=" . $PhoneNumber . "&Published=" . $Published . "&"
                        . "OverRideDuplicate=" . $OverRideDuplicate;

                //id,quitus,url,data,method,date,status,cpteur

                $arrayDataPaieFM = array(
                    "quitus" => $numquitusFM,
                    "url" => CONFIG_URL_MTN,
                    "data" => $urlData,
                    "method" => $method,
                    "status" => 0,
                    "cpteur" => 0,
                    "date" => date('Y-m-d')
                );

                /**
                 * On teste si le candidat a choisi MTN coe banque de paiement
                 */
                //$idbanque
                //$tablePrefix
                $sql = "SELECT * FROM " . $tablePrefix . "banque WHERE id='$idbanque' AND nombanque LIKE '%MTN%'";
                //echo $sql;
                $banque = $db->fetchAll($sql);
//                if (count($banque) != 0) {
//                    $db->insert("paymentsdatatmpmtn", $arrayDataPaieFM);
//                    $db->insert("paymentsdatatmpmtn", $arrayDataPaieFP);
//                }
                $db->insert("paymentsdatatmpmtn", $arrayDataPaieFM);
                $db->insert("paymentsdatatmpmtn", $arrayDataPaieFP);
            }//fin if doublon
        }//fin if POST
    }

    public function editAction() {

        $front = Zend_Layout::getMvcInstance();
        $front->disableLayout();
        //$this->_helper->viewRenderer->setNoRender();
        $infospreinscrit = new Zend_Session_Namespace('infospreinscrit');
        $mysession = new Zend_Session_Namespace('mysession');

        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        $numDossier = $this->_getParam("registnum");
        if (!preg_match("/^[0-9]+$/", $numDossier) == 1) {
            echo "Mauvais num de dossier";
            die();
        }
        $codeetab = $this->_getParam("codeetab");
        $tablePrefix = "siges" . $codeetab . "_";
        $sql = "SELECT U.id AS uid, U.login, E.id AS idetud, E.*, P.*, P.id AS idpreinscription, P.idtypeformation, PA.idBanque, PA.id AS idpaie "
                . "FROM {$tablePrefix}etudiant E "
                . "JOIN {$tablePrefix}preinscription P ON P.idetudiant=E.id "
                . "JOIN liste_nationalite N ON N.id=E.nationaliteetud "
                . "JOIN {$tablePrefix}typeformation T ON T.id=P.idtypeformation "
                . "JOIN {$tablePrefix}payepreinscription PA ON PA.idetudiant=E.id "
                . "JOIN users U ON U.id=E.idUtilisateur "
                . "WHERE P.id='$numDossier'";
        //echo $sql;

        $detailsRegist = $db->fetchAll($sql);
        $this->view->detaitsregist = $detailsRegist;

        $sqlStateFile = "SELECT O.libelle_fr AS optionchoisie,D.date, D.decision,D.observation, E.nometud, E.prenometud,E.datenaissetud, P.datepreinscription FROM {$tablePrefix}etudiant E "
                . "JOIN {$tablePrefix}preinscription P ON P.idetudiant=E.id "
                . "JOIN {$tablePrefix}decisionjurypreinscription D ON D.idpreinscription=P.id  "
                . "JOIN {$tablePrefix}options O ON D.idoptions=O.id  "
                . "WHERE P.id='$numDossier'";
        $this->view->stateFile = $db->fetchAll($sqlStateFile);


        $mysession = new Zend_Session_Namespace('mysession');
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        $etabs = $db->fetchAll("select * from etablissements WHERE code='$codeetab' LIMIT 1");
        $this->view->etab = $etabs[0];
        $prefixTable = "siges" . $codeetab . "_";

        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        $codeEtab = $etabs[0]->code;
        //echo "concours = " . $idConcours . " et codeetab=" . $codeEtab;
        $infospreinscrit = new Zend_Session_Namespace('infospreinscrit');
        $mysession = new Zend_Session_Namespace('mysession');
        $mysession->facPrefix = $codeEtab;

        $this->view->listeDiplomesAdmission = $db->fetchAll("SELECT id, libelle_fr, libelle_en FROM {$prefixTable}diplomeadmission ORDER BY libelle_fr");
        $this->view->listeTypeFormation = $db->fetchAll("SELECT * FROM {$prefixTable}typeformation");
        $this->view->listeClasselmd = $db->fetchAll("SELECT * FROM {$prefixTable}classelmd");
        $this->view->listeoptions = $db->fetchAll("SELECT * FROM {$prefixTable}options");
        $this->view->listeNationalite = $db->fetchAll("SELECT * FROM liste_nationalite");
        $this->view->listeRegions = $db->fetchAll("SELECT * FROM {$prefixTable}region");
        $this->view->listeDeptGeo = $db->fetchAll("SELECT * FROM {$prefixTable}departementgeo");
        $this->view->listeVilles = $db->fetchAll("SELECT * FROM {$prefixTable}ville");
        $this->view->listeBanques = $db->fetchAll("SELECT * FROM {$prefixTable}banque WHERE assigner=1");

        //rubrique infos personnelles etudiant
        //Ernest
        $this->view->premlangofficieletud = $db->fetchAll("select * from liste_langueofficielle");
        $this->view->listeSituatiomfamilliale = $db->fetchAll("select * from liste_situationfamiliale ");
        $this->view->listeSituationEmploi = $db->fetchAll("select * from liste_situationemploi ");
    }

    public function saveeditAction() {
        $infospreinscrit = new Zend_Session_Namespace('infospreinscrit');
        $mysession = new Zend_Session_Namespace('mysession');

        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        if (isset($_POST['diplomeadmission']) and isset($_POST['nometud'])) {
            $tablePrefix = "siges" . $_POST['codeetab'] . "_";
            //else {
            $this->view->doublon = 0;
            ///////////////////////////////////////////////////////////////////////////////////////////

            /* @var $idregion type */
            $idregion = filter_input(INPUT_POST, 'RegionOrigine', FILTER_SANITIZE_NUMBER_INT);
            $regionEtud = $db->fetchAll("SELECT libelle_fr,libelle_en FROM " . $tablePrefix . "region WHERE id='$idregion' LIMIT 1");
            $libelleRegionOrigine = $regionEtud[0]->libelle_fr;

            $iddept = $_POST['DeptOrigine'];
            $deptEtud = $db->fetchAll("SELECT libelle_fr,libelle_en FROM " . $tablePrefix . "departementgeo WHERE id='$iddept' LIMIT 1");
            $libelleDeptOrigine = $deptEtud[0]->libelle_fr;

            $idArr = $_POST['ArrondisOrigine'];
            $arrEtud = $db->fetchAll("SELECT libelle_fr,libelle_en FROM " . $tablePrefix . "ville WHERE id='$idArr' LIMIT 1");
            $libelleArrOrigine = $arrEtud[0]->libelle_fr;

            $idmodeAdmission = $_POST['idmodeAdmission'];
            $modeAdmissionEtud = $db->fetchAll("SELECT * FROM liste_modeadmission WHERE id='$idmodeAdmission' LIMIT 1");
            $libelleModeAdmission = $modeAdmissionEtud[0]->libelle_fr;

            $diplomeadmission = $_POST['diplomeadmission'];
            $da = $db->fetchAll("SELECT libelle_fr FROM " . $tablePrefix . "diplomeadmission WHERE id='$diplomeadmission' LIMIT 1");
            $libelleDiplomeAdmin = $da[0]->libelle_fr;

            $etudObject = new Application_Model_Etudiants();

            $nometud = addslashes(str_replace("  ", " ", trim($_POST['nometud'])));
            $prenometud = addslashes(str_replace("  ", " ", trim($_POST['prenometud'])));
            for ($i = 0; $i <= 3; $i++) {
                $nometud = str_replace("  ", " ", trim($nometud));
                $prenometud = str_replace("  ", " ", trim($prenometud));
            }

            $etudObject->setNometud(trim($nometud));
            $etudObject->setPrenometud(trim($prenometud));

            $dateNaiss = $_POST['anneeNaiss'] . "-" . $_POST['moisNaiss'] . "-" . $_POST['jourNaiss'];

            $etudObject->setDatenaiss(trim($dateNaiss));
            $etudObject->setLieunaiss(ucfirst(trim($_POST['lieuNaissance'])));

            $etudObject->setRegionOrigine(trim($_POST['RegionOrigine']));
            $etudObject->setPremlangofficieletud(trim($_POST['premlangofficieletud']));
            $etudObject->setDeptOrigine(trim($_POST['DeptOrigine']));
            $etudObject->setArrondisOrigine(trim($_POST['ArrondisOrigine']));

            $etudObject->setCivilite(trim($_POST['sexeetud']));
            $etudObject->setCnietud(trim($_POST['cnietud']));
            $etudObject->setSexeetud(trim($_POST['sexeetud']));
            $etudObject->setNationaliteetud(trim($_POST['nationaliteetud']));
            $etudObject->setSituationfamilialetud(trim($_POST['situationfamilialetud']));
            $etudObject->setNbreenfantetud(trim($_POST['nbreenfantetud']));
            $etudObject->setSituationemploietud(trim($_POST['situationemploietud']));
            $etudObject->setHandicape(trim($_POST['handicape']));

            $etudObject->setVilleresidenceetudiant(ucfirst(trim($_POST['villeresidenceetudiant'])));
            $etudObject->setCodeposte(trim($_POST['codeposte']));
            $etudObject->setTelephone(trim($_POST['telephone']));
            $etudObject->setFax(trim($_POST['fax']));
            $etudObject->setEmailetud(trim($_POST['emailetud']));
            $etudObject->setLibelleadresse(ucfirst(trim($_POST['libelleadresse'])));

            $etudObject->setDiplomeadmission($diplomeadmission);
            $etudObject->setAnneeobtensiondiplome(trim($_POST['anneeobtensiondiplome']));
            $etudObject->setNotediplomeetud(trim($_POST['notediplomeetud']));
            $etudObject->setLieuobtention(ucfirst(trim($_POST['lieuobtension'])));

            $etudObject->setMentiondiplome(trim($_POST['notediplomeetud']));

            $etudObject->setMentiondiplome('0');

            $etudObject->setIdmodeadmission($idmodeAdmission);
            $etudObject->setDateinscription(date("Y-m-d"));

            $etudObject->setNompere(ucwords(trim($_POST['nompere'])));
            $etudObject->setProfessionpere(trim($_POST['professionpere']));
            $etudObject->setNommere(ucwords(trim($_POST['nommere'])));
            $etudObject->setProfessionmere(trim($_POST['professionmere']));
            $etudObject->setCodeposteparent(trim($_POST['codeposteparent']));
            $etudObject->setFaxparent(trim($_POST['faxparent']));
            $etudObject->setTelephoneparent(trim($_POST['telephoneparent']));
            $etudObject->setLieuderesidenceparent(ucfirst(trim($_POST['lieuderesidenceparent'])));
            $etudObject->setAdresseparent(trim($_POST['adresseparent']));

            /**
             * Mise à jour Users
             */
            $uid = $_POST['uid'];
            $passwd = $_POST['passwd'];
            if (strlen($passwd) >= 5)
                $db->query("UPDATE users SET passwd=MD5(CONCAT('$passwd',passwd_salt)) WHERE id='$uid' LIMIT 1");



            $data = array(
                'idville' => $etudObject->getArrondisOrigine(),
                'idregion' => $etudObject->getRegionOrigine(),
                'iddepartement' => $etudObject->getDeptOrigine(),
                'idethnie' => '0',
                'lieuNaissance' => $etudObject->getLieunaiss(),
                'idmodeAdmission' => 2, //Etude de dossier
                'codeetudiant' => '',
                'matriculeetud' => $_POST['matriculeetud'],
                'nometud' => $etudObject->getNometud(),
                'prenometud' => $etudObject->getPrenometud(),
                'datenaissetud' => $etudObject->getDatenaiss(),
                'nationaliteetud' => $etudObject->getNationaliteetud(),
                'sexeetud' => $etudObject->getSexeetud(),
                'situationemploietud' => $etudObject->getSituationemploietud(),
                'handicape' => $etudObject->getHandicape(),
                'situationfamilialetud' => $etudObject->getSituationfamilialetud(),
                'nbreenfantetud' => $etudObject->getNbreenfantetud(),
                'premlangofficieletud' => $etudObject->getPremlangofficieletud(),
                'photoetud' => '',
                'villeresidenceetudiant' => $etudObject->getVilleresidenceetudiant(),
                'codeposte' => $etudObject->getCodeposte(),
                'telephone' => $etudObject->getTelephone(),
                'fax' => $etudObject->getFax(),
                'emailetud' => $etudObject->getEmailetud(),
                'libelleadresse' => $etudObject->getLibelleadresse(),
                'diplomeadmission' => $etudObject->getDiplomeadmission(),
                'anneeobtensiondiplome' => $etudObject->getAnneeobtensiondiplome(),
                'lieuobtension' => $_POST['lieuobtention'],
                'mentiondiplome' => $etudObject->getMentiondiplome(),
                'cnietud' => $etudObject->getCnietud(),
                'dateinscription' => $etudObject->getDateinscription(),
                'notediplomeetud' => $_POST['notediplomeetud'],
                'typeimage' => '',
                'numeroseriepremiereinscription' => "",
                'civilite' => $etudObject->getCivilite(),
                'nompere' => $etudObject->getNompere(),
                'professionpere' => $etudObject->getProfessionpere(),
                'nommere' => $etudObject->getNommere(),
                'professionmere' => $etudObject->getProfessionmere(),
                'codeposteparent' => $etudObject->getCodeposteparent(),
                'faxparent' => $etudObject->getFaxparent(),
                'telephoneparent' => $etudObject->getTelephoneparent(),
                'lieuderesidenceparent' => $etudObject->getLieuderesidenceparent(),
                'adresseparent' => $etudObject->getAdresseparent(),
                'ancienid' => '',
                'regionorigine' => $libelleRegionOrigine,
                'departementorigine' => $libelleDeptOrigine,
                'arrondissementorigine' => $libelleArrOrigine,
                'modeadmission' => $libelleModeAdmission,
                'sportpratique' => $_POST['sport'],
                'autresactivites' => $_POST['autresactivites'],
                'contact1' => $_POST['contact1'],
                'telephone1' => $_POST['telephone1'],
                'adresse1' => $_POST['adresse1'],
                'contact2' => $_POST['contact2'],
                'telephone2' => $_POST['telephone2'],
                'adresse2' => $_POST['adresse2'],
                'datedelivrancecni' => $_POST['anneecni'] . "-" . $_POST['moiscni'] . "-" . $_POST['jourcni'],
                'isdiplomesousreserve' => $_POST['isdiplomesousreserve'],
                'seriediplome' => $_POST['seriediplome']
            );

            $where = array(
                "id=?" => $_POST['idetud']
            );

            $mysession->facPrefix = $_POST['codeetab'];

            $db->update($tablePrefix . "etudiant", $data, $where);


            /**
             * Enregistrement de la préinscription
             */
            $idclasselmd = $_POST['classelmd'];

            /**
             * recherche de la catégorie de paiement
             */
            $idNationalite = $_POST['nationaliteetud'];
            /**
             * $tableCatPays = new Application_Model_DbTable_Categoriepays();
             */
            $sql = "SELECT C.idcategoriepayement FROM categoriepays C 
                WHERE C.idnationalite='$idNationalite' LIMIT 1";

            $listCatPaie = $db->fetchAll($sql);
            $idCatPaie = $listCatPaie[0]->idcategoriepayement;
            $infospreinscrit->idcatpaie = $idCatPaie;

            //sigesasa_anneeacademique
            $annees = $db->fetchAll("SELECT id FROM " . $tablePrefix . "anneeacademique WHERE encours=1");
            $idAnneeAcad = $annees[0]->id;

            $tablePreinscript = new Application_Model_DbTable_Preinscription();

            $idtypeformation = $_POST['typeformation'];

            $data = array(
                'idclasse' => $idclasselmd,
                'idtypeformation' => $idtypeformation,
                'idcategoriepayement' => $idCatPaie,
                'idanneeacademique' => $idAnneeAcad,
                'iddoplomeadmission' => $diplomeadmission,
                'datepreinscription' => date("Y-m-d"),
                'datevalidationpreinscription' => '',
                'eligible' => '-1',
                'choix1' => $_POST['option1'],
                'choix2' => $_POST['option2'],
                'choix3' => $_POST['option3'],
                'exportDU' => '0',
                'exportDP' => '0',
                'exportFM' => '0',
                'idcentreconcours' => '',
                'idconcours' => '',
                'idlieudepotdossier' => ''
            );
            //idtypepreinscription,,typeadmission
            //            echo "<pre>";
            //            print_r($data);
            //            echo "</pre>";



            $prefixTab = "siges" . $_POST['codeetab'] . "_";

            $facPrefix = $_POST['codeetab'];
            //echo "<br>prefix->" . $mysession->tablePrefix;
            $tablePreinscript = $tablePrefix . "preinscription";

            $where = array(
                "idEtudiant" => $_POST['idetud'],
                "id" => $_POST['idpreinscription']
            );


            $db->update($tablePreinscript, $data, $where);
            //$tablePreinscript->insert($data);

            $idPreinscription = $_POST['idpreinscription'];

            $infospreinscrit->numpreinscription = $idPreinscription;
            $this->view->idpreinscription = $infospreinscrit->numpreinscription;
            $this->view->facprefix = $facPrefix;

            //$idTypeformation = $infospreinscrit->typeformation;
            //$typeformation = $db->fetchAll("SELECT libelle_fr,libelle_en FROM " . $prefixTab . "typeformation WHERE id='$idTypeformation' LIMIT 1");
            //$infospreinscrit->libtypeformation = $concours[0]->libelle_fr;
            //echo "Libelle_type_form = " . $concours[0]->libelle_fr;

            $idclass = $_POST['classelmd'];
            $classelmd = $db->fetchAll("SELECT libelle_fr,libelle_en FROM " . $prefixTab . "classelmd WHERE id='$idclass' LIMIT 1");


            $infospreinscrit->numpreinscription = $idPreinscription;
            $this->view->idpreinscription = $infospreinscrit->numpreinscription;

            $nationalite = $db->fetchAll("SELECT libelle_fr,libelle_en FROM nationalite WHERE id='$idNationalite' LIMIT 1");
            $infospreinscrit->libnationalite = $nationalite[0]->libelle_fr;

            $modeadmin = $db->fetchAll("SELECT libelle_fr,libelle_en FROM liste_modeadmission WHERE id='$idmodeAdmission' LIMIT 1");
            $infospreinscrit->libmodeadmission = $modeadmin[0]->libelle_fr;


            /////////////////////////////////////////////////////////////////////////////////////////



            /**
             * MAJ de la table paiePreinscription
             */
            $idFP = CONFIG_DP;
            $idFM = CONFIG_FM;

            $idbanque = $_POST['idbanque'];
            $idpaie = $_POST['idpaie'];

            if (!isset($idbanque))
                $idbanque = 1;
            $dataPaie = array(
                "idBanque" => $idbanque,
            );
            $where = array(
                "id = ?" => $idpaie
            );
            $db->update($tablePrefix . "payepreinscription", $dataPaie, $where);




            $infospreinscrit->nometud = $_POST['nometud'];
            $infospreinscrit->prenometud = $_POST['prenometud'];

            $facprefix = $_POST['codeetab'];

            $quitusPreinscription = commonClass::quitusuy($idPreinscription, $facprefix, $tablePrefix, 0);
            $nameQuitusPre = $mysession->quitusName;
            unset($mysession->quitusName);

            $quitusFraisMedico = commonClass::quitusuy($idPreinscription, $facprefix, $tablePrefix, 1);
            $nameQuitusMed = $mysession->quitusName;
            unset($mysession->quitusName);

            $fichePreinscription = commonClass::fichePreinscriptionuy($idPreinscription, $tablePrefix, $facprefix);
            $nameFiche = $mysession->ficheName;
            unset($mysession->ficheName);

            $this->view->quitusPre = $nameQuitusPre;
            $this->view->quitusMed = $nameQuitusMed;
            $this->view->fichePre = $nameFiche;

            $this->view->idPreinscription = $idPreinscription;


            /**
             * Chargement de la table paiementdatatmp
             */
            //idpaie = idetud_idannee_idsession
            //id,url,data,method,status
            $db = Zend_Db_Table_Abstract::getDefaultAdapter();
            $db->setFetchMode(Zend_Db::FETCH_OBJ);
            $url = addslashes("http://localhost/sigesonline/public/paiements/testvalidationpaiements");
            //$url = addslashes("http://sigesonline.univ-dschang.org/paiements/testvalidationpaiements");
            //$url = addslashes("http://192.168.43.17/postuds/validate_post.php");
            //$url = addslashes("http://www.expressexchange.fr:9994/univdschang/post/");


            $data = "";
            $nom = mb_strtoupper(trim($infospreinscrit->nometud));
            $prenom = trim($infospreinscrit->prenometud);
            $telephoneEtud = trim($infospreinscrit->telephone);
            $nomComplet = $_POST['nometud'] . " " . $_POST['prenometud'];

            $sqlLib = "SELECT libelle_fr FROM " . $tablePrefix . "anneeacademique WHERE id='$idAnneeAcad' LIMIT 1";
            $annees = $db->fetchAll($sqlLib);
            $libelleAnneeAcad = $annees[0]->libelle_fr;
            $libelleAnneeAcad = str_replace('/', '-', $libelleAnneeAcad);
            $telephoneEtud = str_replace('/', '-', $telephoneEtud);
            $telephoneEtud = str_replace(' ', '', $telephoneEtud);

            $dataFM = array(
                "numquitus" => $numquitusFM,
                "nometudiant" => urlencode($nomComplet),
                "montant" => $montantFM,
                "idpaie" => $indicePaieFM,
                "telephone" => $telephoneEtud,
                "idetudiant" => $idEtudiant,
                "annee" => $libelleAnneeAcad,
                "_username" => 'univ_uy2',
                "_pwd" => 'testdschang'
            );

            $dataFP = array(
                "numquitus" => $numquitusFP,
                "nometudiant" => urlencode($nomComplet),
                "montant" => $montantFP,
                "idpaie" => $indicePaieFP,
                "telephone" => $telephoneEtud,
                "idetudiant" => $idEtudiant,
                "annee" => $libelleAnneeAcad,
                "_username" => 'univ_uy2',
                "_pwd" => 'testdschang'
            );

            $method = "POST";
            $arrayDataPaieFM = array(
                "url" => $url,
                "data" => json_encode($dataFM),
                "method" => $method,
                "status" => 0,
                "date" => date('Y-m-d')
            );


            $arrayDataPaieFP = array(
                "url" => $url,
                "data" => json_encode($dataFP),
                "method" => $method,
                "status" => 0,
                "date" => date('Y-m-d')
            );

            $whereFP = array(
                "quitus = ?" => $numquitusFP
            );
            $whereFM = array(
                "quitus = ?" => $numquitusFM
            );
            $db->update("paymentsdatatmp", $arrayDataPaieFM, $whereFM);
            $db->update("paymentsdatatmp", $arrayDataPaieFP, $whereFP);





            /**
             * Chargement de la table paiementdatatmpEU
             */
            $login = CONFIG_USER_EU;
            $ip = CONFIG_IP_EU;
            $pwd = CONFIG_USER_PASS_EU;
            $sig = CONFIG_SIG_EU;

            //Frais de preinscription

            $idpaiement = $indicePaieFP;
            $numquitus = $numquitusFP;
            $nom_etudiant = urlencode($nomComplet);
            $montant = $montantFP;
            $annee = $libelleAnneeAcad;
            $idetudiant = $idEtudiant;
            $tranche = '0';
            $type_fac = substr($numquitus, 0, 1);
            $type_paie = substr($numquitus, 1, 1);
            $urlData = CONFIG_URL_EU . "?login=" . $login . "&ip=" . $ip . "&pwd=" . $pwd . "&sig=" . $sig . ""
                    . "&idpaiement=" . $idpaiement . "&numquitus=" . $numquitus . "&nom_etudiant=" . $nom_etudiant . "&montant=" . $montant . ""
                    . "&annee=" . $annee . "&idetudiant=" . $idetudiant . "&tranche=" . $tranche . "&type_fac=" . $type_fac . "&type_paie=" . $type_paie;

            //id,quitus,url,data,method,date,status,cpteur
            $arrayDataPaieFP = array(
                "url" => CONFIG_URL_EU,
                "data" => $urlData,
                "method" => $method,
                "status" => 0,
                "cpteur" => 0,
                "date" => date('Y-m-d')
            );

            $idpaiement = $indicePaieFM;
            $numquitus = $numquitusFM;
            $nom_etudiant = urlencode($nomComplet);
            $montant = $montantFM;
            $annee = $libelleAnneeAcad;
            $idetudiant = $idEtudiant;
            $tranche = '0';
            $type_fac = substr($numquitus, 0, 1);
            $type_paie = substr($numquitus, 1, 1);
            $urlData = CONFIG_URL_EU . "?login=" . $login . "&ip=" . $ip . "&pwd=" . $pwd . "&sig=" . $sig . ""
                    . "&idpaiement=" . $idpaiement . "&numquitus=" . $numquitus . "&nom_etudiant=" . $nom_etudiant . "&montant=" . $montant . ""
                    . "&annee=" . $annee . "&idetudiant=" . $idetudiant . "&tranche=" . $tranche . "&type_fac=" . $type_fac . "&type_paie=" . $type_paie;
            //id,quitus,url,data,method,date,status,cpteur
            $arrayDataPaieFM = array(
                "url" => CONFIG_URL_EU,
                "data" => $urlData,
                "method" => $method,
                "status" => 0,
                "cpteur" => 0,
                "date" => date('Y-m-d')
            );



            $whereFP = array(
                "quitus = ?" => $numquitusFP
            );
            $whereFM = array(
                "quitus = ?" => $numquitusFM
            );
            $db->update("paymentsdatatmp", $arrayDataPaieFM, $whereFM);
            $db->update("paymentsdatatmp", $arrayDataPaieFP, $whereFP);


            /*             * ******************************************************************************* */
            /**
             * Chargement de la table paiementdatatmpMTN
             */
            //Frais de preinscription        

            $CustomerName = urlencode($nomComplet);
            $BillReference = $libelleAnneeAcad;
            $BillNumber = $numquitusFP;
            $BillDate = date('d/m/Y');
            $annee = date('Y') + 1;
            $mois = date('m');
            $jour = date('d');
            //Date d'expiration du paiement
            //Nous mettons à l'année suivante
            $ExpiryDate = $jour . '/' . $mois . '/' . $annee;
            $CountryPhoneCode = CONFIG_COUNTRY_PHONECODE;
            $Amount = $montantFP;
            $MinimumPayment = $montantFP;
            $ExpiryPenaltyAmount = 0;
            $Currency = "XAF";
            $Informations = "";
            $PhoneNumber = commonClass::phoneValidator($telephoneEtud);
            $Published = 1;           //---0 or 1
            $OverRideDuplicate = 1;    //---0 or 1
            $urlData = "CustomerName=" . $CustomerName . "&"
                    . "BillReference=" . $BillReference . "&BillNumber=" . $BillNumber . "&BillDate=" . $BillDate . "&ExpiryDate=" . $ExpiryDate . "&"
                    . "CountryPhoneCode=" . $CountryPhoneCode . "&Amount=" . $Amount . "&MinimumPayment=" . $MinimumPayment . "&ExpiryPenaltyAmount=" . $ExpiryPenaltyAmount . "&"
                    . "Currency=" . $Currency . "&Informations=" . $Informations . "&PhoneNumber=" . $PhoneNumber . "&Published=" . $Published . "&"
                    . "OverRideDuplicate=" . $OverRideDuplicate;

            //id,quitus,url,data,method,date,status,cpteur
            $arrayDataPaieFP = array(
                "url" => CONFIG_URL_MTN,
                "data" => $urlData,
                "method" => $method,
                "status" => 0,
                "cpteur" => 0,
                "date" => date('Y-m-d')
            );


            /**
             * Frais medicaux
             */
            $CustomerName = urlencode($nomComplet);
            $BillReference = $libelleAnneeAcad;
            $BillNumber = $numquitusFM;
            $BillDate = date('d/m/Y');
            $annee = date('Y') + 1;
            $mois = date('m');
            $jour = date('d');
            //Date d'expiration du paiement
            //Nous mettons à l'année suivante
            $ExpiryDate = $jour . '/' . $mois . '/' . $annee;
            $CountryPhoneCode = CONFIG_COUNTRY_PHONECODE;
            $Amount = $montantFM;
            $MinimumPayment = $montantFM;
            $ExpiryPenaltyAmount = 0;
            $Currency = "XAF";
            $Informations = "";
            $PhoneNumber = commonClass::phoneValidator($telephoneEtud);
            $Published = 1;           //---0 or 1
            $OverRideDuplicate = 1;    //---0 or 1
            $urlData = "CustomerName=" . $CustomerName . "&"
                    . "BillReference=" . $BillReference . "&BillNumber=" . $BillNumber . "&BillDate=" . $BillDate . "&ExpiryDate=" . $ExpiryDate . "&"
                    . "CountryPhoneCode=" . $CountryPhoneCode . "&Amount=" . $Amount . "&MinimumPayment=" . $MinimumPayment . "&ExpiryPenaltyAmount=" . $ExpiryPenaltyAmount . "&"
                    . "Currency=" . $Currency . "&Informations=" . $Informations . "&PhoneNumber=" . $PhoneNumber . "&Published=" . $Published . "&"
                    . "OverRideDuplicate=" . $OverRideDuplicate;

            //id,quitus,url,data,method,date,status,cpteur

            $arrayDataPaieFM = array(
                "url" => CONFIG_URL_MTN,
                "data" => $urlData,
                "method" => $method,
                "status" => 0,
                "cpteur" => 0,
                "date" => date('Y-m-d')
            );

            /**
             * On teste si le candidat a choisi MTN coe banque de paiement
             */
            //$idbanque
            //$tablePrefix
            $sql = "SELECT * FROM " . $tablePrefix . "banque WHERE id='$idbanque' AND nombanque LIKE '%MTN%'";
            //echo $sql;
            $banque = $db->fetchAll($sql);
            if (count($banque) != 0) {

                $whereFP = array(
                    "quitus = ?" => $numquitusFP
                );
                $whereFM = array(
                    "quitus = ?" => $numquitusFM
                );
                $db->update("paymentsdatatmpmtn", $arrayDataPaieFM, $whereFM);
                $db->update("paymentsdatatmpmtn", $arrayDataPaieFP, $whereFP);
            }



            //}//fin if doublon
        }//fin if POST
    }

    public function addAction() {
        $mysession = new Zend_Session_Namespace('mysession');
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);
        $idEtab = $this->_getParam("e");
        $etabs = $db->fetchAll("select * from etablissements WHERE id='$idEtab' LIMIT 1");
        $this->view->etab = $etabs[0];
        $prefixTable = "siges" . $etabs[0]->code . "_";

        if (isset($_POST['codeetabedit'])) {
            echo "POST chargé";
            print_r($_POST);
        }

        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        $codeEtab = $etabs[0]->code;
        //echo "concours = " . $idConcours . " et codeetab=" . $codeEtab;
        $infospreinscrit = new Zend_Session_Namespace('infospreinscrit');
        $mysession = new Zend_Session_Namespace('mysession');
        $mysession->facPrefix = $codeEtab;

        $this->view->listeDiplomesAdmission = $db->fetchAll("SELECT id, libelle_fr, libelle_en FROM {$prefixTable}diplomeadmission ORDER BY libelle_fr");
        $this->view->listeTypeFormation = $db->fetchAll("SELECT * FROM {$prefixTable}typeformation");
        $this->view->listeClasselmd = $db->fetchAll("SELECT * FROM {$prefixTable}classelmd");
        $this->view->listeoptions = $db->fetchAll("SELECT * FROM {$prefixTable}options");
        $this->view->listeNationalite = $db->fetchAll("SELECT * FROM liste_nationalite");
        $this->view->listeRegions = $db->fetchAll("SELECT * FROM {$prefixTable}region");
        $this->view->listeBanques = $db->fetchAll("SELECT * FROM {$prefixTable}banque WHERE assigner=1");

        //rubrique infos personnelles etudiant
        //Ernest
        $this->view->premlangofficieletud = $db->fetchAll("select * from liste_langueofficielle");
        $this->view->listeSituatiomfamilliale = $db->fetchAll("select * from liste_situationfamiliale ");
        $this->view->listeSituationEmploi = $db->fetchAll("select * from liste_situationemploi ");
    }

    public function updatedeptAction() {
        // action body
        $front = Zend_Layout::getMvcInstance();
        $front->disableLayout();
        $this->_helper->viewRenderer->setNoRender();
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        $idRegion = $this->_request->getParam('idRegion');
        $codeetab = $this->_request->getParam('codeetab');
        $prefixTable = "siges" . $codeetab . "_";
        $mysession = new Zend_Session_Namespace('mysession');
        $lang = $mysession->lang;
        $libelle = 'libelle_' . $lang;
        $listeDept = $db->fetchAll("SELECT * FROM {$prefixTable}departementgeo WHERE idregion='$idRegion'");

        echo "<select name=\"DeptOrigine\" id=\"DeptOrigine\" class=\"requis form-control\" onchange=\"chargearrondis()\">
        <option value='' selected='selected'>" . T_CHOOSE . "</option>";
        foreach ($listeDept as $dept) {
            echo '<option value=' . $dept->id . '>' . $dept->$libelle . '</option>';
        }
        echo "</select>";
        echo '<span class="textRequis" id="error_DeptOrigine"></span><span id="id_wait_dept"></span>';
    }

    public function updateclasseAction() {
        // action body
        $front = Zend_Layout::getMvcInstance();
        $front->disableLayout();
        $this->_helper->viewRenderer->setNoRender();
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        $idDiplome = $this->_request->getParam('idDiplome');
        $codeetab = $this->_request->getParam('codeetab');

        $prefixTable = "siges" . $codeetab . "_";
        $tablePrefix = $prefixTable;
        $mysession = new Zend_Session_Namespace('mysession');
        $lang = $mysession->lang;
        $libelle = 'libelle_' . $lang;
        $sqlClasseLMD = "SELECT C.id,C.libelle_fr,C.libelle_en 
                        FROM " . $tablePrefix . "classelmd C
                        JOIN " . $tablePrefix . "optiondiplomeadmission ODC ON C.id=ODC.idclasse
                        JOIN " . $tablePrefix . "diplomeadmission DA ON DA.id=ODC.iddiplomeadmission 
                        WHERE DA.id='$idDiplome' GROUP BY C.id
                   ";


        $resultClasse = $db->fetchAll($sqlClasseLMD);

        $is_admin = $this->_getParam("is_admin");
        echo "<select name=\"classelmd\" class=\"requis\" id=\"classelmd\" onchange=\"chargeOptions('" . $is_admin . "');\">";
        //echo "<select name=\"classelmd\" class=\"requis\" id=\"classelmd\" onchange=\"chargeOptions();\">";    
        echo "<option value=\"\">" . T_CHOOSE . "</option>";
        foreach ($resultClasse as $classe) {
            echo '<option value=' . $classe['id'] . '>' . $classe['libelle_fr'] . '</option>';
        }
        echo "</select>";
        echo "</span><span id=\"wait_classe\"></span> <span class=\"textRequis\" id=\"error_classelmd\"></span>";
    }

    public function updateoptionsAction() {
        // action body
        $front = Zend_Layout::getMvcInstance();
        $front->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        $mysession = new Zend_Session_Namespace('mysession');

        $codeetab = $this->_request->getParam('codeetab');
        $prefixTable = "siges" . $codeetab . "_";
        $tablePrefix = $prefixTable;

        $idDiplome = $this->_request->getParam('idDiplome');
        $idClasselmd = $this->_request->getParam('idClasselmd');
        $idTypeFormation = $this->_request->getParam('idTypeFormation');
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();

        $sql = "select O.id,O.libelle_fr,O.libelle_en,cursus,finalite 
                    FROM " . $tablePrefix . "options O
                    JOIN " . $tablePrefix . "optiondiplomeadmission ODA ON ODA.idoption=O.id
                    JOIN " . $tablePrefix . "typeformationoption TFO ON TFO.idoption=O.id
                    WHERE ODA.idclasse='$idClasselmd' AND ODA.iddiplomeadmission='$idDiplome' AND TFO.idtypeformation='$idTypeFormation' 
					ORDER BY O.libelle_fr";
        /**
         * Je masque certaines options
         * 24 = SECO PRO CF

          if($tablePrefix == "sigesseg_") {
          $sql =  "select O.id,O.libelle_fr,O.libelle_en,cursus,finalite
          FROM ".$tablePrefix."options O
          JOIN ".$tablePrefix."optiondiplomeadmission ODA ON ODA.idoption=O.id
          JOIN ".$tablePrefix."typeformationoption TFO ON TFO.idoption=O.id
          WHERE ODA.idclasse='$idClasselmd' AND ODA.iddiplomeadmission='$idDiplome' AND TFO.idtypeformation='$idTypeFormation'
          AND O.id!=24
          ORDER BY O.libelle_fr ";
          }
         */
        //echo $sql;  
        $resultOptions = $db->fetchAll($sql);

        echo "<table width=\"100%\" class=\"admintable\">";
        echo "<tr><td colspan=\"2\" align=\"\"><span id=\"id_wait_options\"></span></td></tr>";
        echo "<tr>";
        echo "<td class=\"key\">" . T_CHOIX_FORMATION1 . "<span class=\"Style2\">*</span></td>";
        echo "<td>";
        echo "<select name=\"option1\" id=\"option1\" class=\"requis\">
       <option value='' selected='selected'>Choisir</option>";
        foreach ($resultOptions as $option) {
            echo '<option value=' . $option['id'] . '>' . $option['cursus'] . ' ' . $option['finalite'] . ' ' . $option['libelle_fr'] . '</option>';
        }
        echo "</select>";
        echo "</span> <span class=\"textRequis\" id=\"error_option1\"></span>";
        echo "</td></tr>";

        echo "<tr>";
        echo "<td class=\"key\">" . T_CHOIX_FORMATION2 . "<span class=\"Style2\">*</span></td>";
        echo "<td>";
        echo "<select name=\"option2\" id=\"option2\" class=\"requis\">
       <option value='' selected='selected'>Choisir</option>";
        foreach ($resultOptions as $option) {
            echo '<option value=' . $option['id'] . '>' . $option['cursus'] . ' ' . $option['finalite'] . ' ' . $option['libelle_fr'] . '</option>';
        }
        echo "</select>";
        echo "</span> <span class=\"textRequis\" id=\"error_option2\"></span>";
        echo "</td></tr>";

        echo "<tr>";
        echo "<td class=\"key\">" . T_CHOIX_FORMATION3 . "<span class=\"Style2\">*</span></td>";
        echo "<td>";
        echo "<select name=\"option3\" id=\"option3\" class=\"requis\">
       <option value='' selected='selected'>Choisir</option>";
        foreach ($resultOptions as $option) {
            echo '<option value=' . $option['id'] . '>' . $option['cursus'] . ' ' . $option['finalite'] . ' ' . $option['libelle_fr'] . '</option>';
        }
        echo "</select>";
        echo "</span> <span class=\"textRequis\" id=\"error_option3\"></span>";
        echo "</td></tr>";

        echo '</table>';
    }

    public function updatearrondisAction() {
        // action body

        $front = Zend_Layout::getMvcInstance();
        $front->disableLayout();
        $this->_helper->viewRenderer->setNoRender();
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);
        $idDept = $this->_request->getParam('iddept');
        $codeetab = $this->_request->getParam('codeetab');
        $prefixTable = "siges" . $codeetab . "_";
        $mysession = new Zend_Session_Namespace('mysession');
        $lang = $mysession->lang;
        $libelle = 'libelle_' . $lang;
        $listeArrondis = $db->fetchAll("SELECT * FROM {$prefixTable}ville WHERE iddepartementgeo='$idDept'");

        echo "<select name=\"ArrondisOrigine\" id=\"ArrondisOrigine\" class=\"requis form-control\" onchange=\"chekArrondis()\">
        <option value='' selected='selected'>Choisir</option>";
        foreach ($listeArrondis as $arrondis) {
            echo '<option value=' . $arrondis->id . '>' . $arrondis->libelle_fr . '</option>';
        }
        echo "</select>";
        echo '<span class="textRequis" id="error_ArrondisOrigine"></span><span id="id_wait_Arrondis"></span>';
    }

    public function loadblocsAction() {
        $mysession = new Zend_Session_Namespace('mysession');
        $front = Zend_Layout::getMvcInstance();
        $front->disableLayout();
        //$this->_helper->viewRenderer->setNoRender();
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);
        $fonction = $this->_getParam("fonction");
        $this->view->fonction = $fonction;
        switch ($fonction) {
            case "detailspreins":
                $numDossier = $this->_getParam("registnum");
                if (!preg_match("/^[0-9]+$/", $numDossier) == 1) {
                    echo "Mauvais num de dossier";
                    die();
                }
                $codeetab = $this->_getParam("codeetab");
                $tablePrefix = "siges" . $codeetab . "_";
                $sql = "SELECT E.nometud, E.prenometud,E.datenaissetud, P.datepreinscription FROM {$tablePrefix}etudiant E "
                        . "JOIN {$tablePrefix}preinscription P ON P.idetudiant=E.id "
                        . "WHERE P.id='$numDossier'";
                //echo $sql;
                $detailsRegist = $db->fetchAll($sql);
                $this->view->detaitsregist = $detailsRegist;
                break;
            case "checkFileStatus":
                $numDossier = $this->_getParam("registnum");
                if (!preg_match("/^[0-9]+$/", $numDossier) == 1) {
                    echo "Mauvais num de dossier";
                    die();
                }
                $codeetab = $this->_getParam("codeetab");
                $tablePrefix = "siges" . $codeetab . "_";
                $sql = "SELECT O.libelle_fr AS optionchoisie,D.date, D.decision,D.observation, E.nometud, E.prenometud,E.datenaissetud, P.datepreinscription FROM {$tablePrefix}etudiant E "
                        . "JOIN {$tablePrefix}preinscription P ON P.idetudiant=E.id "
                        . "JOIN {$tablePrefix}decisionjurypreinscription D ON D.idpreinscription=P.id  "
                        . "JOIN {$tablePrefix}options O ON D.idoptions=O.id  "
                        . "WHERE P.id='$numDossier'";
                //echo $sql;
                $detailsRegist = $db->fetchAll($sql);
                $this->view->detaitsregist = $detailsRegist;
                break;
            case "downloaddocs":
                $numDossier = $this->_getParam("registnum");
                if (!preg_match("/^[0-9]+$/", $numDossier) == 1) {
                    echo "Mauvais num de dossier";
                    die();
                }
                $codeetab = $this->_getParam("codeetab");
                $facprefix = $codeetab;
                $tablePrefix = "siges" . $facprefix . "_";
                $idpreinscription = $numDossier;

                $quitusPreinscription = commonClass::quitusuy($idpreinscription, $facprefix, $tablePrefix, 0);
                $nameQuitusPre = $mysession->quitusName;
                unset($mysession->quitusName);

                $quitusPreinscription = commonClass::quitusuy($idpreinscription, $facprefix, $tablePrefix, 1);
                $nameQuitusMed = $mysession->quitusName;
                unset($mysession->quitusName);


                $fichePreinscription = commonClass::fichePreinscriptionuy($idpreinscription, $tablePrefix, $facprefix);
                $nameFiche = $mysession->ficheName;
                unset($mysession->ficheName);

                $this->view->numdossier = $idpreinscription;

                $this->view->quitusPre = $nameQuitusPre;
                $this->view->quitusMed = $nameQuitusMed;
                $this->view->fichePre = $nameFiche;
                break;

            case "chargeClasse":
                $codeetab = $this->_getParam("codeetab");
                $facprefix = $codeetab;
                $tablePrefix = "siges" . $facprefix . "_";
                $idDiplome = $this->_request->getParam('idDiplome');
                $sqlClasse = "SELECT C.id,C.libelle_fr,C.libelle_en 
                        FROM " . $tablePrefix . "classelmd C
                        JOIN " . $tablePrefix . "optiondiplomeadmission ODC ON C.id=ODC.idclasse
                        JOIN " . $tablePrefix . "diplomeadmission DA ON DA.id=ODC.iddiplomeadmission 
                        WHERE DA.id='$idDiplome' GROUP BY C.id
                   ";
                //echo $sqlClasse;
                $this->view->listeClasselmd = $db->fetchAll($sqlClasse);

                break;

            case "chargeOptions":
                $codeetab = $this->_getParam("codeetab");
                $facprefix = $codeetab;
                $tablePrefix = "siges" . $facprefix . "_";
                $idDiplome = $this->_request->getParam('idDiplome');
                $idClasselmd = $this->_request->getParam('idClasselmd');
                $idTypeFormation = $this->_request->getParam('idTypeFormation');

                $sqlOptions = "select O.id,O.libelle_fr,O.libelle_en,cursus,finalite 
                    FROM " . $tablePrefix . "options O
                    JOIN " . $tablePrefix . "optiondiplomeadmission ODA ON ODA.idoption=O.id
                    JOIN " . $tablePrefix . "typeformationoption TFO ON TFO.idoption=O.id
                    WHERE ODA.idclasse='$idClasselmd' AND ODA.iddiplomeadmission='$idDiplome' AND TFO.idtypeformation='$idTypeFormation' 
					ORDER BY O.libelle_fr";
                //echo $sqlOptions;
                $this->view->listeoptions = $db->fetchAll($sqlOptions);
                break;
        }
    }

//    public function loadblocsmsAction() {
//        $mysession = new Zend_Session_Namespace('mysession');
//        $front = Zend_Layout::getMvcInstance();
//        $front->disableLayout();
//        //$this->_helper->viewRenderer->setNoRender();
//        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
//        $db->setFetchMode(Zend_Db::FETCH_OBJ);
//        $fonction = $this->_getParam("fonction");
//        $this->view->fonction = $fonction;
//        switch ($fonction) {
//
//            case "detailspreins":
//                $numDossier = $this->_getParam("registnum");
//                $codeetab = $this->_getParam("codeetab");
//                $tablePrefix = "siges" . $codeetab . "_";
//                echo "Num dossier = " . $numDossier;
//                break;
//
//
//
//            case "loadcontactslist":
//                $motcle = $this->_getParam("motcle");
//                $contacts = $db->fetchAll("SELECT * "
//                        . "FROM contactssms "
//                        . "WHERE nom LIKE '%$motcle%' OR tel LIKE '%$motcle%'");
//                $this->view->contactsList = $contacts;
//                break;
//
//            case "loadsmslist":
//                $motcle = $this->_getParam("motcle");
//                $SMSTemplate = $db->fetchAll("SELECT * "
//                        . "FROM smstemplate "
//                        . "WHERE titre LIKE '%$motcle%' OR msg LIKE '%$motcle%'");
//                $this->view->SMSList = $SMSTemplate;
//                break;
//
//            case "loadgroupslist":
//                $motcle = $this->_getParam("motcle");
//                $SMSGroup = $db->fetchAll("SELECT * "
//                        . "FROM groupesms "
//                        . "WHERE nom LIKE '%$motcle%' OR description LIKE '%$motcle%'");
//                $this->view->groupsList = $SMSGroup;
//                break;
//
//            case "loadsmstemplatelist":
//                $motcle = $this->_getParam("motcle");
//                $SMSTemplate = $db->fetchAll("SELECT * "
//                        . "FROM smstemplate "
//                        . "WHERE titre LIKE '%$motcle%' OR msg LIKE '%$motcle%'");
//                $this->view->SMSTemplateList = $SMSTemplate;
//                break;
//
//            case "loadcontactsMod":
//                $idcontact = $this->_getParam("idcontact");
//                $contacts = $db->fetchAll("SELECT * "
//                        . "FROM contactssms "
//                        . "WHERE id='$idcontact' LIMIT 1");
//                $this->view->contact = $contacts[0];
//
//                $groupsContact = $db->fetchAll("SELECT * "
//                        . "FROM contactssmsgroupe "
//                        . "WHERE idcontact='$idcontact'");
//                $this->view->groupsContact = $groupsContact;
//
//                $groups = $db->fetchAll("SELECT G.id,G.nom,G.description FROM groupesms G");
//                $this->view->groups = $groups;
//
//                $nbContactGroup = array();
//                foreach ($groups as $group) {
//                    $nbContactGroup[$group->id] = 0;
//                }
//
//                $groups = $db->fetchAll("SELECT G.id,G.nom, COUNT(*) AS 'NbContacts' FROM groupesms G "
//                        . "JOIN contactssmsgroupe CG ON G.id=CG.idgroupe "
//                        . "JOIN contactssms C ON C.id=CG.idcontact "
//                        . "GROUP BY G.id ORDER BY G.nom");
//                //$this->view->groups = $groups;
//
//
//                foreach ($groups as $group) {
//                    $nbContactGroup[$group->id] = $group->NbContacts;
//                }
//                $this->view->nbContactGroup = $nbContactGroup;
//
//
//
//                break;
//
//            case "modcontact":
//                $idcontact = $this->_getParam("idcontact");
//                $nom = $this->_getParam("nom");
//                $tel = $this->_getParam("tel");
//                $email = $this->_getParam("email");
//                $active = $this->_getParam("active");
//                $listeGroup = $this->_getParam("listegroups");
//                //echo "<div class='success'>$idcontact | $nom | $tel | $email | $active | $listeGroup</div>";
//
//                $dataContact = array(
//                    'nom' => $nom,
//                    'tel' => $tel,
//                    'email' => $email,
//                    'statut' => $active
//                );
//                $where = array("id=?" => $idcontact);
//                $update = $db->update("contactssms", $dataContact, $where);
//                //On supprime le fichier public/autocomplete/files/completer.json
//                if (file_exists("autocomplete/files/completer.json")) {
//                    unlink("autocomplete/files/completer.json");
//                    //echo "Fichier JSON supprime";
//                } else {
//                    //echo "Le fichier autocomplete/files/completer.json est introuvable";
//                }
//
//
//                if ($update == 1 or $update == 0) {
//                    //echo "IDS GROUP = " . $listeGroup;;
//                    $idgroups = explode("-", $listeGroup);
//                    $where = array("idcontact=?" => $idcontact);
//                    $delete = $db->delete("contactssmsgroupe", array('idcontact = ?' => $idcontact));
//                    foreach ($idgroups as $idgroup) {
//                        //on enregistre les modifications
//                        if ($idgroup != '') {
//                            $dataGroupContact = array(
//                                "idcontact" => $idcontact,
//                                "idgroupe" => $idgroup
//                            );
//                            //echo "<br>";
//                            //print_r($dataGroupContact);
//                            $insertContactGroupe = $db->insert("contactssmsgroupe", $dataGroupContact);
//                        }
//                    }
//                    echo "<div class='success'>Mise à jour effectuée avec succès!!!</div>";
//                } else {
//                    echo "<div class='error'>Erreur de mise à jour!!!</div>";
//                }
//
//                break;
//
//            case "loaddeptlist":
//                $codeEtab = $this->_getParam("codeetab");
//                $this->view->listeDept = $db->fetchAll("SELECT id, libelle_fr FROM siges{$codeEtab}_departementacademique ");
//                break;
//            case "loadoptionslist":
//                $idDept = $this->_getParam("idDept");
//                $codeEtab = $this->_getParam("codeetab");
//                $this->view->listeOptions = $db->fetchAll("SELECT id, libelle_fr FROM siges{$codeEtab}_options WHERE iddepartement='$idDept'");
//                break;
//            case "loadlevellist":
//                $codeEtab = $this->_getParam("codeetab");
//                $this->view->listeNiveaux = $db->fetchAll("SELECT id, code, libelle_fr FROM siges{$codeEtab}_classelmd ");
//                break;
//
//            case "loadstudentsdetails":
//                $codeEtab = $this->_getParam("codeetab");
//                $idDept = $this->_getParam("idDept");
//                $idOpt = $this->_getParam("idopt");
//                $codeClasse = $this->_getParam("idclasse");
//                //echo "CodeEtab=" . $codeEtab . " idDept=" . $idDept . " idopt=" . $idOpt . " idClasse=" . $codeClasse;
//                $req = "SELECT ID,TEL FROM siges{$codeEtab}_etudiantsinscrits WHERE ID IS NOT NULL ";
//                $req .= ($idDept == '0') ? "" : "AND iddepartement='$idDept' ";
//                $req .= ($idOpt == '0') ? "" : "AND idoption='$idOpt' ";
//                $req .= ($codeClasse == '0') ? "" : "AND NIVEAU='$codeClasse' ";
//                //echo $req;
//                $this->view->listeContacts = $db->fetchAll($req);
//                $this->view->listeSMS = $db->fetchAll("SELECT id, TRIM(titre) AS titre,TRIM(msg) AS msg,TRIM(datecreation) AS datecreation "
//                        . "FROM smstemplate ORDER BY id DESC LIMIT 5");
//                break;
//            case 'loadstaffdetails':
//                $GIDs = $this->_getParam("GIDs");
//                $sql = "SELECT C.tel AS TEL "
//                        . "FROM contactssms C "
//                        . "JOIN contactssmsgroupe CG ON CG.idcontact=C.id "
//                        . "JOIN groupesms G ON G.id=CG.idgroupe "
//                        . "WHERE G.id IN ($GIDs)";
//                //echo "________________________________________" . $sql;
//                $this->view->listeContacts = $db->fetchAll($sql);
//                $this->view->listeSMS = $db->fetchAll("SELECT id, TRIM(titre) AS titre,TRIM(msg) AS msg,TRIM(datecreation) AS datecreation "
//                        . "FROM smstemplate ORDER BY id DESC LIMIT 5");
//                break;
//
//            case "reportsavecron":
//                $mysession = new Zend_Session_Namespace('mysession');
//                $uid = $mysession->user['id'];
//                $codeEtab = $this->_getParam("codeetab");
//                // data = "fonction=" + fonction + "&to=" + $("#to").val() + "&idsms=" + $('input[name=msg]:checked').val()
//                //+ "&dateenvoi=" + $("#dateenvoi").val() + "&heureenvoi=" + $("#heureenvoi").val();
//                $to = $this->_getParam("to");
//                $idsms = $this->_getParam("idsms");
//                $dateenvoi = $this->_getParam("dateenvoi");
//                $heureenvoi = $this->_getParam("heureenvoi");
//                $desc = $this->_getParam("desc");
//                $smslimit = $this->_getParam("smslimit");
//                $dataInsertCron = array(
//                    "dateenvoi" => $dateenvoi,
//                    "heureenvoi" => $heureenvoi,
//                    "description" => $desc,
//                    "idsms" => $idsms,
//                    "uid" => $mysession->user['id'],
//                    "datecreation" => date("Y-d-m")
//                );
//                $tabTo = explode(";", $to);
//                $smslimit = ($smslimit > 0) ? $smslimit : count($tabTo);
//                $saveSMSSender = 1;
//                if ($db->insert("smscronstudents", $dataInsertCron)) {
//                    $this->view->savecron = 1;
//                    //Ici, on enregistre les destinataires dans la table smssender
//                    $nb = 0;
//                    foreach ($tabTo as $to) {
//                        //echo "<br>" . $to;
//                        //id, destinataire, idcron, statut,dateenvoye
//                        //On retrouve le last ID du cron créé par cet user
//                        $sqlLastCron = "SELECT * "
//                                . "FROM smscronstudents "
//                                . "WHERE uid='$uid' AND dateenvoi='$dateenvoi' AND heureenvoi='$heureenvoi'";
//
//                        $crons = $db->fetchAll($sqlLastCron);
//                        $idCron = $crons[0]->id;
//                        if (strlen($to) == 12) {
//                            $dataSMSSender = array(
//                                "destinataire" => $to,
//                                "idcron" => $idCron
//                            );
//                            $db->insert("smssenderstudents", $dataSMSSender);
//                            $nb ++;
//                        }
//                        if ($nb == $smslimit)
//                            break;
//                    }
//                } else
//                    $this->view->save = 0;
//                break;
//
//            case "reportsavecronstaff":
//                $mysession = new Zend_Session_Namespace('mysession');
//                $uid = $mysession->user['id'];
//                $codeEtab = $this->_getParam("codeetab");
//                // data = "fonction=" + fonction + "&to=" + $("#to").val() + "&idsms=" + $('input[name=msg]:checked').val()
//                //+ "&dateenvoi=" + $("#dateenvoi").val() + "&heureenvoi=" + $("#heureenvoi").val();
//                $to = $this->_getParam("to");
//                //echo $to;
//                $idsms = $this->_getParam("idsms");
//                $dateenvoi = $this->_getParam("dateenvoi");
//                $heureenvoi = $this->_getParam("heureenvoi");
//                $desc = $this->_getParam("desc");
//                $smslimit = $this->_getParam("smslimit");
//
//                $dataInsertCron = array(
//                    "dateenvoi" => $dateenvoi,
//                    "heureenvoi" => $heureenvoi,
//                    "description" => $desc,
//                    "idsms" => $idsms,
//                    "uid" => $mysession->user['id'],
//                    "datecreation" => date("Y-m-d")
//                );
//                //print_r($dataInsertCron);
//
//
//                $tabTo = explode(";", $to);
//                $smslimit = ($smslimit > 0) ? $smslimit : count($tabTo);
//
//                $saveSMSSender = 1;
//                if ($db->insert("smscronstaff", $dataInsertCron)) {
//                    $this->view->savecron = 1;
//                    //Ici, on enregistre les destinataires dans la table smssender
//                    //On retrouve le last ID du cron créé par cet user
//                    $sqlLastCron = "SELECT * "
//                            . "FROM smscronstaff "
//                            . "WHERE uid='$uid' AND dateenvoi='$dateenvoi' AND heureenvoi='$heureenvoi' ORDER BY id DESC LIMIT 1";
//
//                    $crons = $db->fetchAll($sqlLastCron);
//                    $idCron = $crons[0]->id;
//                    $nb = 0;
//                    foreach ($tabTo as $to) {
//                        //echo "<br>" . $to;
//                        //id, destinataire, idcron, statut,dateenvoye
//                        if (strlen($to) == 12) {
//                            $dataSMSSender = array(
//                                "destinataire" => $to,
//                                "idcron" => $idCron
//                            );
//                            $db->insert("smssenderstaff", $dataSMSSender);
//                            $nb ++;
//                        }
//                        if ($nb == $smslimit)
//                            break;
//                    }
//                } else
//                    $this->view->save = 0;
//                break;
//
//
//
//            case 'activecron':
//                $idCron = $this->_getParam("idcron");
//                if ($db->query("UPDATE smscronstudents SET active=IF(active=1,0,1) WHERE id='$idCron' LIMIT 1"))
//                    $this->view->activeCron = 1;
//                $crons = $db->fetchAll("SELECT * FROM smscronstudents WHERE id='$idCron' LIMIT 1");
//                $this->view->idcron = $idCron;
//                $this->view->tache = $crons[0];
//                break;
//
//            case 'editcron':
//                $idCron = $this->_getParam("idcron");
//                $crons = $db->fetchAll("SELECT * FROM smscronstudents WHERE id='$idCron' LIMIT 1");
//                $this->view->idcron = $idCron;
//                $this->view->tache = $crons[0];
//                break;
//
//            case 'activecronstaff':
//                $idCron = $this->_getParam("idcron");
//                if ($db->query("UPDATE smscronstaff SET active=IF(active=1,0,1) WHERE id='$idCron' LIMIT 1"))
//                    $this->view->activeCron = 1;
//                $crons = $db->fetchAll("SELECT * FROM smscronstaff WHERE id='$idCron' LIMIT 1");
//                $this->view->idcron = $idCron;
//                $this->view->tache = $crons[0];
//                break;
//
//            case 'editcronstaff':
//                $idCron = $this->_getParam("idcron");
//                $crons = $db->fetchAll("SELECT * FROM smscronstaff WHERE id='$idCron' LIMIT 1");
//                $this->view->idcron = $idCron;
//                $this->view->tache = $crons[0];
//                break;
//
//            case 'updatecron':
//                $idCron = $this->_getParam("idcron");
//                $dateenvoi = $this->_getParam("dateenvoi");
//                $heureenvoi = $this->_getParam("heureenvoi");
//                $desc = $this->_getParam("descron");
//                $dataUpdateCron = array(
//                    "dateenvoi" => $dateenvoi,
//                    "heureenvoi" => $heureenvoi,
//                    "description" => $desc,
//                    "uid" => $mysession->user['id']
//                );
//
//                if ($db->update("smscronstudents", $dataUpdateCron, "id='$idCron'")) {
//                    $this->view->updateCron = 1;
//                }
//
//                $crons = $db->fetchAll("SELECT * FROM smscronstudents WHERE id='$idCron' LIMIT 1");
//                $this->view->idcron = $idCron;
//                $this->view->tache = $crons[0];
//                break;
//
//            case 'updatecronstaff':
//                $idCron = $this->_getParam("idcron");
//                $dateenvoi = $this->_getParam("dateenvoi");
//                $heureenvoi = $this->_getParam("heureenvoi");
//                $desc = $this->_getParam("descron");
//                $dataUpdateCron = array(
//                    "dateenvoi" => $dateenvoi,
//                    "heureenvoi" => $heureenvoi,
//                    "description" => $desc,
//                    "uid" => $mysession->user['id']
//                );
//
//                if ($db->update("smscronstaff", $dataUpdateCron, "id='$idCron'")) {
//                    $this->view->updateCron = 1;
//                }
//
//                $crons = $db->fetchAll("SELECT * FROM smscronstaff WHERE id='$idCron' LIMIT 1");
//                $this->view->idcron = $idCron;
//                $this->view->tache = $crons[0];
//                break;
//
//            default:
//                break;
//        }
//    }
//
//    public function studentshedulerAction() {
//        $mysession = new Zend_Session_Namespace('mysession');
//        $uid = $mysession->user['id'];
//        $db = Zend_Db_Table::getDefaultAdapter();
//        $db->setFetchMode(Zend_Db::FETCH_OBJ);
//        $this->view->listeSMS = $db->fetchAll("SELECT id, TRIM(titre) AS titre,TRIM(msg) AS msg,TRIM(datecreation) AS datecreation "
//                . "FROM smstemplate ORDER BY id DESC LIMIT 10");
//        $this->view->listeAnneeAcad = $db->fetchAll("SELECT id, codeanneeacad, libelle_fr "
//                . "FROM sigesasa_anneeacademique "
//                . " WHERE codeanneeacad>15 ORDER BY ordre desc");
//        $this->view->listeEtab = $db->fetchAll("SELECT code,codenum,nometablissement_fr,codepublic "
//                . "FROM etablissements "
//                . "WHERE code!='asacfb'");
//        //echo "SELECT * FROM smscronstudents WHERE uid='$uid' ORDER BY id DESC LIMIT 10 ";
//        $this->view->listTaches = $db->fetchAll("SELECT * FROM smscronstudents WHERE uid='$uid' ORDER BY id DESC LIMIT 10 ");
//    }
//
//    public function studentsrandomshedulerAction() {
//        $mysession = new Zend_Session_Namespace('mysession');
//        $db = Zend_Db_Table::getDefaultAdapter();
//        $db->setFetchMode(Zend_Db::FETCH_OBJ);
//        $this->view->listeSMS = $db->fetchAll("SELECT id, TRIM(titre) AS titre,TRIM(msg) AS msg,TRIM(datecreation) AS datecreation FROM smstemplate ORDER BY id DESC LIMIT 5");
//    }
//
//    public function staffshedulerAction() {
//        $mysession = new Zend_Session_Namespace('mysession');
//        $db = Zend_Db_Table::getDefaultAdapter();
//        $db->setFetchMode(Zend_Db::FETCH_OBJ);
//        $uid = $mysession->user['id'];
//        $this->view->listeSMS = $db->fetchAll("SELECT id, TRIM(titre) AS titre,TRIM(msg) AS msg,TRIM(datecreation) AS datecreation FROM smstemplate ORDER BY id DESC LIMIT 5");
//        $sqlSelectGroups = "SELECT G.id,G.nom, COUNT(*) AS 'NbContacts' "
//                . "FROM groupesms G "
//                . "JOIN contactssmsgroupe CG ON G.id=CG.idgroupe "
//                . "JOIN contactssms C ON C.id=CG.idcontact "
//                . "GROUP BY G.id ORDER BY G.nom";
//        $this->view->listeGroupes = $db->fetchAll($sqlSelectGroups);
//        $this->view->listTaches = $db->fetchAll("SELECT * FROM smscronstaff WHERE uid='$uid' ORDER BY id DESC LIMIT 10 ");
//    }

}

/**
 * CLASSE DE FONCTIONS
 */
class commonfunctions {

    public function sendsmsdatanew2($tel, $text) {

        $ch = curl_init();
        //Lecture de toutes les lignes qui n'ont pas encore �t� envoy�es (STATUT=0)
        //////////////////////////////////////////////////////////////////
        /**
         * GTS 
         */
        $url = "http://5.39.75.139:22086/message";
        $data = "user=UDS&pass=uds@123&from=UNIVDSCHANG&to=" . $tel . "&text=" . $text . "&dlrreq=1";


        /**
         * TEST AVEC MEDIAFONE 
         */
        //http://196.202.235.146/mediasms/index.php?app=ws&u=udslogsms1&op=pv&h=0777213d9c69701391781a64e0125ac6&to=237699839858&msg=test+only
        //$url = "http://196.202.235.146/mediasms/index.php";
        //$data = "app=ws&u=udslogsms1&op=pv&h=0777213d9c69701391781a64e0125ac6&to=" . $tel . "&msg=" . $text;
        //Pour tester le crédit, 
        // http://196.202.235.146/mediasms/index.php?app=ws&u=udslogsms1&op=cr&h=0777213d9c69701391781a64e0125ac6
        $url = "http://196.202.235.146/mediasms/index.php";
        $data = "app=ws&u=siewe&op=pv&from=OrangeMoney&h=c101022b4108a3b2eeda9ddc50b114bf&to=" . $tel . "&msg=" . $text;
        //Pour tester le crédit, 
        // http://196.202.235.146/mediasms/index.php?app=ws&u=siewe&op=cr&h=c101022b4108a3b2eeda9ddc50b114bf



        /**
         * TEST NEXMO
         */
        //https://rest.nexmo.com/sms/json?api_key=e43f958d&api_secret=472463873e2dae4c&from=NEXMO&to=237677087432&text=Welcome+to+Nexmo
//        $url = "https://rest.nexmo.com/sms/json";
//        $data = "api_key=e43f958d&api_secret=472463873e2dae4c&from=NEXMO&to=" . $tel . "&text=" . $text;



        /**
         * $data est sous la forme htp://url?paramètres
         * On doit pourtant enlever la partie http://url?
         */
        $postdata = $data; // @http_build_query($data);
        $opts = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-type: application/x-www-form-urlencoded',
                'content' => $postdata)
        );

        $context = stream_context_create($opts);
        //echo $postdata;
        //$resultat = "TEST";
        $resultat = @file_get_contents($url, false, $context);
        if (strlen($resultat) == 0) {
            echo "<br>Error!!!!!!" . $data;
        } else {
            //echo $resultat;
            $resultat = trim($resultat);

            /*
              if (substr($resultat, 0, 2) == "OK") {
              echo "<br>" . "Message envoyé à " . $tel;
              $db = Zend_Db_Table_Abstract::getDefaultAdapter();
              $db->setFetchMode(Zend_Db::FETCH_OBJ);
              $nbChar = (int) (strlen($text));
              $nbrePages = ceil($nbChar / 160);
              $mysession = new Zend_Session_Namespace('mysession');
              $data = array(
              'destinataire' => $tel,
              'iduser' => $mysession->user['id'],
              'msg' => urldecode($text),
              'nbrepages' => $nbrePages,
              'dateenvoi' => date('Y-m-d'),
              'statut' => 1
              );
              //print_r($data);
              $db->insert("sms", $data);
              } else {
              echo "<br>Echec d'envoi de message à " . $tel;
              echo "<br>" . $resultat;
              }

              /*

              /**
             * RECUPERATION DU RESULTAT AVEC MEDIAFONE
             * */
            $resultat = json_decode($resultat);
            //print_r($resultat);
            //echo "<br>" . ($resultat->data[0]->status);
            if (($resultat->data[0]->status) == "OK") {
                echo "<br>" . "Message envoyé à " . $tel;
                $db = Zend_Db_Table_Abstract::getDefaultAdapter();
                $db->setFetchMode(Zend_Db::FETCH_OBJ);
                $nbChar = (int) (strlen($text));
                $nbrePages = ceil($nbChar / 160);
                $mysession = new Zend_Session_Namespace('mysession');
                $data = array(
                    'destinataire' => $tel,
                    'iduser' => $mysession->user['id'],
                    'msg' => urldecode($text),
                    'nbrepages' => $nbrePages,
                    'dateenvoi' => date('Y-m-d'),
                    'statut' => 1
                );
                //print_r($data);
                $db->insert("sms", $data);
            } else {
                echo "<br>Echec d'envoi de message à " . $tel;
                echo $resultat;
            }
        }
        ////////////////////////////////////////////////////////////
        // Fermeture de la ressource CURL et lib�ration des ressources syst�mes
        curl_close($ch);
    }

    public function isavailable($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_exec($ch);
        if (!curl_errno($ch)) {
            curl_close($ch);
            return TRUE;
        } else {
            curl_close($ch);
            return FALSE;
        }
    }

}
