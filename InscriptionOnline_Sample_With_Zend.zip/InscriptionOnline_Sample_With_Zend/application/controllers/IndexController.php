<?php

//echo "<h1>En maintenance, veuillez revenir dans un ainstant</h1>";

require_once 'BaseController.php';

class IndexController extends BaseController {

    public function init() {
        $mysession = new Zend_Session_Namespace('mysession');
        $mysession->facPrefix = $mysession->user->fac;
        $mysession->menu = "accueil";
        parent::init();
        $this->view->option = $this->_getParam("option");
    }

    public function indexAction() {
        //$id = (int)$this->_request->getParam('id');
        $mysession = new Zend_Session_Namespace('mysession');
        $mysession->menu = "accueil";

        if ($this->_hasParam('lang')) {
            $lang = $this->_request->getParam('lang');
            $mysession->lang = $lang;
            $this->_redirect();
        }

        $db = Zend_Db_Table::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);
        
    }

    public function testAction() {
        
    }

    public function formAction() {
        
    }

    public function testjsonAction() {
        $front = Zend_Layout::getMvcInstance();
        $front->disableLayout();
        $this->_helper->viewRenderer->setNoRender();
        $data = array(
            "code" => 0,
            "status" => 0,
            "msg" => "Non enregistre"
        );
        echo json_encode($data);
    }

    public function extractionanneeAction($matricule, $posAnne) {
        /**
         * Ce script permet d'extraire le code de l'année dans un 
         * matricule donné.
         * En entrée: 
         *     $matricule est le matricule proprement dit
         *     $post permet de savoir si le code de l'année vient après ou avant le numéro de série
         *         Ses valeurs possibles 1 (avant) ou 2 (après)
         * On retourne le code de l'année en sortie
         */
        $tabMat = str_split($matricule);
        $codeAnnee = "";
        $numSerie = "";
        $unNumericTrouve = false;
        for ($i = 0; $i < count($tabMat); $i++) {
            $c = $tabMat[$i];
            if (is_numeric($c)) {
                $codeAnnee .= $c;
                $unNumericTrouve = true;
            } else {
                if ($unNumericTrouve) {
                    if (strlen($codeAnnee) < 2) {
                        //On réinitialise le compteur et on continu
                        $codeAnnee = "";
                        $unNumericTrouve = false;
                    } else {
                        //A ce niveau, on aura obtenu un code valide
                        //On sort donc de la boucle
                        break;
                    }
                }
            }
        }

        if ($posAnne == 2) {
            $numSerie = $codeAnnee;
            $codeAnnee = "";
            $unNumericTrouve = false;
            for ($j = $i; $j < count($tabMat); $j++) {
                $c = $tabMat[$j];
                if (is_numeric($c)) {
                    $codeAnnee .= $c;
                    $unNumericTrouve = true;
                } else {
                    if ($unNumericTrouve) {
                        if (strlen($codeAnnee) < 2) {
                            //On réinitialise le compteur et on continu
                            $codeAnnee = "";
                            $unNumericTrouve = false;
                        } else {
                            break;
                        }
                    }
                }
            }
        }

        //Si le code de l'année a plus de 02 caractères, on prend les 02 derniers
        if (strlen($codeAnnee) > 2)
            $codeAnnee = substr($codeAnnee, (int) (strlen($codeAnnee) - 2), 2);

        //Si on se trompe sur la position du codeAnnee, on considère le numéro de série
        if ((strlen($codeAnnee) < 2)) {
            //echo "La longueur du code annee est : " . strlen($codeAnnee) .  " et le codeannee est " . $codeAnnee;
            //echo "<br>Le code de lannee est sup a 16 | " . (intval($codeAnnee) - 16);
            $codeAnnee = substr($numSerie, (int) (strlen($numSerie) - 2), 2);
        }
        return $codeAnnee;
    }

    public function readmeAction() {
        // disable layout
        $this->_helper->layout->disableLayout();
        // get readme.html and adjust paths so CSS, images etc are correctly loaded
        $readme = file_get_contents("../readme.html");
        $this->view->readme = str_replace("public/", "/", $readme);
    }

    public function add1Action() {
        // action body
    }

    public function setmenuAction() {
        $menu = $this->_request->getParam('menu');
        $mysession = new Zend_Session_Namespace('mysession');
        $mysession->menu = $menu;
        //$this->_forward($this->getRequest()->getActionName(), $this->getRequest()->getControllerName());
    }

    public function showonlineguestAction() {
        $front = Zend_Layout::getMvcInstance();
        $front->disableLayout();
        $this->_helper->viewRenderer->setNoRender();

        $compteur = commonClass::getNbConnected();

        echo "Il y a <b> " . $compteur['visits'] . "</b> ";
        echo ((int) $compteur['visits'] > 1) ? 'visiteurs' : 'visiteur';
        echo " et <b>" . $compteur['members'] . "</b> ";
        echo ((int) $compteur['members'] > 1) ? ' membres' : ' membre';
        echo " en ligne";
    }

    public function communiquesAction() {
        
    }

}
