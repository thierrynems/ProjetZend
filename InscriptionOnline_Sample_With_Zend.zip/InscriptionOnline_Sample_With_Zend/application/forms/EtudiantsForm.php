
<?php

include_once 'Zend_Validate_UniqueRefNo.php';
include_once 'Zend_Validate_IsNumber.php';

class Application_Form_EtudiantsForm extends Zend_Form {

    public function init() {
        $this->setMethod("post");
        //$this->setAction("/Etudiants/saveForm");
        $this->setAttribs(array(
            'name'  => 'etudiantsForm',
            'id' => 'myform',
       ));
        
      
       
         
         
        //------------------------------------------------------------------
        //------------------------------------------------------------------
        $element = new Zend_Form_Element_Text("nom", array(
                    "label" => T_NAME,
                ));
        //$element->addValidator(new Zend_Validate_UniqueRefNo(), true);
        $element->setRequired(true);
        $element->AddFilters(array('StringToUpper'));
        $element->setErrorMessages(array("Votre nom est obligatoire"));
        $element->setDecorators(array(
            array('ViewScript',
                array(
                    'viewScript' => 'formElements/etudiants/_textInput.phtml'
                )
            )
        ));
        //$this->setDecorators($decoratorElem );
        $this->addElement($element);
        //--------------------------------------------------------------
        $element = new Zend_Form_Element_Text("prenom", array(
                    "label" => T_SURNAME,
                ));
        $element->setDecorators(array(
            array('ViewScript',
                array(
                    'viewScript' => 'formElements/etudiants/_textInput.phtml'
                )
            )
        ));
        $element->setRequired(FALSE);
        //$element->addValidator(new Zend_Validate_IsNumber(), true);
        $this->addElement($element);
        //---------------------------------------------------------------
        $element = new Zend_Form_Element_Text("datenaiss", array(
                    "label" => T_BIRTHDAY,
                ));
        $element->setDecorators(array(
            array('ViewScript',
                array(
                    'viewScript' => 'formElements/etudiants/_textInput.phtml'
                )
            )
        ));
        $element->setValue(date("Y-m-d"));
        $element->setRequired(true);
        $this->addElement($element);
        
             //---------------------------------------------------------------
        $element = new Zend_Form_Element_Text("lieunaiss", array(
                    "label" => T_BIRTHPLACE,
                ));
        //$element->setAttrib('value', '');
        $element->setDecorators(array(
            array('ViewScript',
                array(
                    'viewScript' => 'formElements/etudiants/_textInput.phtml'
                )
            )
        ));
        $element->setRequired(true);
        $this->addElement($element);
        //-------------------------------------------------------------------        
        
//        $this->clearDecorators();
//		$this->addDecorator('FormElements')
//		//->addDecorator('HtmlTag', array('tag' => '<fieldset>'))
//                ->addDecorator ( 'Fieldset', array ('legend' => 'Coordonnées' ) )
//		->addDecorator('Form');
        
         $element = new Zend_Form_Element_Text("idadresse", array(
                    "label" => T_ADDRESS,
                ));
        $element->setDecorators(array(
            array('ViewScript',
                array(
                    'viewScript' => 'formElements/etudiants/_textInput.phtml'
                )
            )
        ));
        $element->setValue("1");
        $element->setRequired(true);        
        $element->addValidator(new Zend_Validate_IsNumber(), true);
        $element->setErrorMessages(array("Votre idadresse doit être composé de chiffres uniquement."));
        
        $this->addElement($element);
        //-------------------------------------------------------------------
         
        $this->addDisplayGroup(array('nom','prenom','datenaiss','lieunaiss','idadresse'), 'groups', array("legend" => T_PERS_INFOS));
        
        
        /**                 
         * 
         * $form->setAttrib('class', 'admin_form');
         
         $group = new Zend_Form_Element_Text('group');
         $form->addElement($group);
         $group->setLabel('Group');
         
         $form->addDisplayGroup(array('group'), 'groups', array("legend" => "Group Add"));
         
         $submit = new Zend_Form_Element_Submit('submit');
         $form->addElement($submit);
         //$submit->setLabel('Save');
         $form->submit->setValue("Save");
         * 
         * **/
        
//
//        $locations = new Application_Model_PropertyLocationMapper();
//        foreach ($locations->fetchAll() as $value) {
//            $options[$value->getId()] = $value->getCity() . " - " . $value->getCityPart();
//        }
//
//        $options = array();
//        $type = new Application_Model_PropertyBuildTypeMapper();
//        $options[''] = '';
//        foreach ($type->fetchAll() as $value) {
//            $options[$value->getId()] = $value->getText();
//        }
//        $element = new Zend_Form_Element_Select("property_build_id", array(
//                    'label' => 'Building type',
//                ));
//        $element->setMultiOptions($options);
//        $element->setDecorators(array(
//            array('ViewScript', array(
//                    'viewScript' => 'formElements/property/_select.phtml'
//                )
//            )
//        ));
//
//        $element->setRequired(true);
//        $element->addValidator(new Zend_Validate_NotEmpty());
//        $this->addElement($element);
//
//        $options = array();
//
//        for ($i = 0; $i < 25; $i++) {
//            $options[$i] = $i;
//        }
//        $element = new Zend_Form_Element_Select("floor", array(
//                    'label' => 'Floor',
//                ));
//        $element->setMultiOptions($options);
//        $element->setDecorators(array(
//            array('ViewScript', array(
//                    'viewScript' => 'formElements/property/_select.phtml'
//                )
//            )
//        ));
//
//        $element->setRequired(true);
//        $element->addValidator(new Zend_Validate_NotEmpty());
//        $this->addElement($element);
//
//        $options = array();
//        $dis = new Application_Model_DispositionMapper();
//        $options[''] = '';
//        foreach ($dis->fetchAll() as $value) {
//            $options[$value->getId()] = $value->getText();
//        }
//        $element = new Zend_Form_Element_Select("disposition_id", array(
//                    'label' => 'Disposition',
//                ));
//        $element->setMultiOptions($options);
//        $element->setDecorators(array(
//            array('ViewScript', array(
//                    'viewScript' => 'formElements/property/_select.phtml'
//                )
//            )
//        ));
//        $element->setRequired(true);
//        $element->addValidator(new Zend_Validate_NotEmpty());
//        $this->addElement($element);
//
//        $element = new Zend_Form_Element_Text("area", array(
//                    "label" => "Area (m&sup2;)",
//                ));
//        $element->setDecorators(array(
//            array('ViewScript',
//                array(
//                    'viewScript' => 'formElements/property/_textInput.phtml'
//                )
//            )
//        ));
//        $element->addValidator(new Zend_Validate_IsNumber(), true);
//        $this->addElement($element);
//
//
//        $element = new Zend_Form_Element_Text("cellar", array(
//                    "label" => "Cellar (m&sup2;)",
//                ));
//        $element->setDecorators(array(
//            array('ViewScript',
//                array(
//                    'viewScript' => 'formElements/property/_textInput.phtml'
//                )
//            )
//        ));
//        $element->addValidator(new Zend_Validate_IsNumber(), true);
//        $this->addElement($element);
//
//        $element = new Zend_Form_Element_Text("balcony", array(
//                    "label" => "Balcony (m&sup2;)",
//                ));
//        $element->setDecorators(array(
//            array('ViewScript',
//                array(
//                    'viewScript' => 'formElements/property/_textInput.phtml'
//                )
//            )
//        ));
//        $element->addValidator(new Zend_Validate_IsNumber(), true);
//        $this->addElement($element);
//
//        $element = new Zend_Form_Element_Text("terace", array(
//                    "label" => "Terrace (m&sup2;)",
//                ));
//        $element->setDecorators(array(
//            array('ViewScript',
//                array(
//                    'viewScript' => 'formElements/property/_textInput.phtml'
//                )
//            )
//        ));
//        $element->addValidator(new Zend_Validate_IsNumber(), true);
//        $this->addElement($element);
//
//        $element = new Zend_Form_Element_Text("loggia", array(
//                    "label" => "Loggia (m&sup2;)",
//                ));
//        $element->setDecorators(array(
//            array('ViewScript',
//                array(
//                    'viewScript' => 'formElements/property/_textInput.phtml'
//                )
//            )
//        ));
//        $element->addValidator(new Zend_Validate_IsNumber(), true);
//        $this->addElement($element);
//
//        $element = new Zend_Form_Element_Text("garage", array(
//                    "label" => "Garage (m&sup2;)",
//                ));
//        $element->setDecorators(array(
//            array('ViewScript',
//                array(
//                    'viewScript' => 'formElements/property/_textInput.phtml'
//                )
//            )
//        ));
//        $element->addValidator(new Zend_Validate_IsNumber(), true);
//        $this->addElement($element);
//
//        $element = new Zend_Form_Element_Text("garden", array(
//                    "label" => "Garden (m&sup2;)",
//                ));
//        $element->setDecorators(array(
//            array('ViewScript',
//                array(
//                    'viewScript' => 'formElements/property/_textInput.phtml'
//                )
//            )
//        ));
//        $element->addValidator(new Zend_Validate_IsNumber(), true);
//        $this->addElement($element);
//
//        $element = new Zend_Form_Element_Checkbox("lift", array(
//                    "label" => "Lift"
//                ));
//        $this->addElement($element);
//
//        $element = new Zend_Form_Element_Checkbox("parking_place", array(
//                    "label" => "Parking place:"
//                ));
//        $this->addElement($element);
//
//
//        $options = array();
//        $dis = new Application_Model_PropertyLocationMapper();
//        $options[''] = '';
//        foreach ($dis->fetchAll() as $value) {
//            $options[$value->getId()] = $value->getCity() . " - " . $value->getCityPart();
//        }
//        $element = new Zend_Form_Element_Select("location_id", array(
//                    'label' => 'Location',
//                ));
//        $element->setMultiOptions($options);
//        $element->setDecorators(array(
//            array('ViewScript', array(
//                    'viewScript' => 'formElements/property/_select.phtml'
//                )
//            )
//        ));
//
//        $element->setRequired(true);
//        $element->addValidator(new Zend_Validate_NotEmpty());
//        $this->addElement($element);
//
//        $element = new Zend_Form_Element_Text("street", array(
//                    "label" => "Address",
//                ));
//        $element->setDecorators(array(
//            array('ViewScript',
//                array(
//                    'viewScript' => 'formElements/property/_textInput.phtml'
//                )
//            )
//        ));
//        $this->addElement($element);
//
//        $element = new Zend_Form_Element_Text("c1", array());
//        $element->setDecorators(array(array('ViewScript', array('viewScript' => 'formElements/property/_clear.phtml'))));
//        $this->addElement($element);
//
//
//        $element = new Zend_Form_Element_Textarea("text", array(
//                    "label" => "Description",
//                ));
//        $element->setDecorators(array(
//            array('ViewScript',
//                array(
//                    'viewScript' => 'formElements/property/_textArea.phtml'
//                )
//            )
//        ));
//        $element->setRequired(true);
//        $this->addElement($element);
//
//
          
         //$submit = new Zend_Form_Element_Submit('submit');
         //$this->addElement($submit);
         //$submit->setLabel('Save');
        // $this->submit->setValue("Save");
        
        
        $element = new Zend_Form_Element_Submit("submit", array(
                    "value" => T_SAVE,
                    "class" => "bouton",
                    "title" => "Cliquez ici pour valider votre formulaire"
                ));
        $element->setDecorators(array(
            array('ViewScript',
                array(
                    'viewScript' => 'formElements/etudiants/_submit.phtml'
                )
            )
        ));
        $this->addElement($element);
        
        $element = new Zend_Form_Element_Reset("reset",
                array(
                    "value" => T_RESET,
                    "class" => "bouton",
                    "title" => "Cliquez ici pour valider votre formulaire"
                )
                );
        
         $element->setDecorators(array(
            array('ViewScript',
                array(
                    'viewScript' => 'formElements/etudiants/_reset.phtml'
                )
            )
        ));
         $this->addElement($element);
        
         $this->addDisplayGroup(array('submit','reset'), 'groups2', array("legend" => T_ACTIONS));
    }

}

