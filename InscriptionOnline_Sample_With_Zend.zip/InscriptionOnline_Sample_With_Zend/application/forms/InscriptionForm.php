<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Application_Form_InscriptionForm extends Zend_Form {

    public function init() {
        $element = new Zend_Form_Element_Text("nom", array(
        "label" => T_NAME,
        ));
        //$element->addValidator(new Zend_Validate_UniqueRefNo(), true);
        $element->setRequired(true);
        $element->AddFilters(array('StringToUpper'));
        $element->setErrorMessages(array("Votre nom est obligatoire"));
        $element->setDecorators(array(
        array('ViewScript',
        array(
        'viewScript' => 'formElements/etudiants/_textInput.phtml'
        )
        )
        ));
        //$this->setDecorators($decoratorElem );
        $this->addElement($element);


        $element = new Zend_Form_Element_Submit("submit", array(
        "value" => T_SAVE,
        "class" => "bouton",
        "title" => "Cliquez ici pour valider votre formulaire"
        ));
        $element->setDecorators(array(
        array('ViewScript',
        array(
        'viewScript' => 'formElements/etudiants/_submit.phtml'
        )
        )
        ));
        $this->addElement($element);

        $element = new Zend_Form_Element_Reset("reset",
        array(
        "value" => T_RESET,
        "class" => "bouton",
        "title" => "Cliquez ici pour valider votre formulaire"
        )
        );

        $element->setDecorators(array(
        array('ViewScript',
        array(
        'viewScript' => 'formElements/etudiants/_reset.phtml'
        )
        )
        ));
        $this->addElement($element);

        $this->addDisplayGroup(array('nom','submit', 'reset'), 'groups2', array("legend" => T_ACTIONS));
}

public function isValid($data)
{
    $password = $this->getElement('password');
    $password->addValidator(new App_Validate_PasswordMatch($data['repassword']));

    return parent::isValid($data);
    
}

}

?>
