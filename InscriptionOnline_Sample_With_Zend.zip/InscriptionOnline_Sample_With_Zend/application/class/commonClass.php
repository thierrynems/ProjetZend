<?php

class commonClass {

    public static function getUnivInfos() {
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);
        $mysession = new Zend_Session_Namespace('mysession');
        if (!isset($mysession->univInfos) or $mysession->univInfos == '') {
            $univInfos = $db->fetchAll("SELECT idUniversite,codeuniversite,libelleunivlngune,libelleunivlngdeux,telephone,siteweb FROM universite");
            $mysession->univInfos = $univInfos[0];
        }
    }

    public static function getTeamInfos() {
        $db = Zend_Db_Table_Abstract::getDefaultAdapter();
        $db->setFetchMode(Zend_Db::FETCH_OBJ);
        $mysession = new Zend_Session_Namespace('mysession');
        if (!isset($mysession->teamInfos) or $mysession->teamInfos == '') {
            $teamInfos = $db->fetchAll("SELECT id,name,phone,email FROM technicalteam");
            $mysession->teamInfos = $teamInfos[0];
        }
    }
}

