<?php

final class Misc_Utils {

    private function __construct() {
    }

    public static function getPerex($text) {
        if (mb_strlen($text) > 200) {
            $firstPor = mb_substr($text, 0, 200);
            $space = mb_strrpos($firstPor, " ");
            return mb_substr($firstPor, 0, $space) . " ...";
        }
        return $text;
    }

    /**
     * @return ArrayObject
     */
    public static function getFavorites() {
        $session = new Zend_Session_Namespace('favorites');
        if ($session->favorites === null) {
            $session->setExpirationSeconds(2592000);
            $session->favorites = new ArrayObject(array());
        }
        return $session->favorites;
    }

    public static function addToFavorites($id) {
        if (is_numeric($id)) {
            self::getFavorites()->offsetSet($id, $id);
        }
    }

    public static function removeFromFavorites($id) {
        if (self::isInFavorites($id)) {
            self::getFavorites()->offsetUnset($id);
        }
    }

    public static function isInFavorites($id) {
        if (is_numeric($id)) {
            return self::getFavorites()->offsetExists($id);
        }
        return false;
    }

}

