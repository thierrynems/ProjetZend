<?php

class Application_Model_DbTable_Etudiants extends Zend_Db_Table_Abstract {

    protected $_name = 'etudiant';
    function init() {
        $mysession = new Zend_Session_Namespace('mysession');
        $facPrefix = $mysession->facPrefix;
        $tablePrefix = 'siges' . $facPrefix . '_';
        $this->_name = $tablePrefix . $this->_name;
        parent::init();       
    }

}

