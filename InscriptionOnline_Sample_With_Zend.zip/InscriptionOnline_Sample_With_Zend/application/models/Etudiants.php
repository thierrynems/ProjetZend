<?php

class Application_Model_Etudiants
{
    
    protected $nometud;
    protected $prenometud;
    protected $datenaissetud;
    protected $lieuNaissance; 
   
    protected $RegionOrigine;
    protected $premlangofficieletud;
    protected $DeptOrigine;
    protected $ArrondisOrigine;
    //protected $arrondisNew;
    protected $civilite;
    protected $cnietud;
    protected $sexeetud;
    protected $nationaliteetud;
    protected $situationfamilialetud;
    protected $nbreenfantetud;
    protected $situationemploietud;
    protected $handicape;
	
    protected $villeresidenceetudiant;
    protected $codeposte; 
    protected $telephone;
    protected $fax;
    protected $emailetud;
    protected $libelleadresse;
//
    protected $diplomeadmission;
    protected $anneeobtensiondiplome;
    protected $notediplomeetud;
    protected $lieuobtention;
    
    protected $mentiondiplome;
    protected $idmodeadmission;
     
    protected $dateinscription;        
    protected $nompere;
    protected $professionpere;
    protected $nommere;
    protected $professionmere;
    protected $codeposteparent;
    protected $faxparent;
    protected $telephoneparent;
    protected $lieuderesidenceparent;
    protected $adresseparent;
    protected $seriediplome;  
   
    protected $id;
    protected $idUtilisateur;
   
    public function __construct(array $options = null) {
        if (is_array($options)) {
            $this->setOptions($options);
        }
    }

    public function __set($name, $value) {
        $method = 'set' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid content student');
        }
        $this->$method($value);
    }

    public function __get($name) {
        $method = 'get' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid content student');
        }
        return $this->$method();
    }

    public function setOptions(array $options) {
        $methods = get_class_methods($this);
        foreach ($options as $key => $value) {
            $method = 'set' . ucfirst($key);
            if (in_array($method, $methods)) {
                $this->$method($value);
            }
        }
        return $this;
    }

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

     public function getIdUtilisateur() {
        return $this->idUtilisateur;
    }

    public function setIdUtilisateur($idUtilisateur) {
        $this->idUtilisateur = $idUtilisateur;
    } 
    
    public function getNometud() {
        return $this->nometud;
    }

    public function setNometud($nometud) {
        $this->nometud = $nometud;
    }


    public function getPrenometud() {
        return $this->prenometud;
    }

    public function setPrenometud($prenometud) {
        $this->prenometud = $prenometud;
    }


    public function getDatenaiss() {
        return $this->DateNaiss;
    }

    public function setDatenaiss($DateNaiss) {
        $this->DateNaiss = $DateNaiss;
    }

    public function getLieunaiss() {
        return $this->lieuNaissance;
    }

    public function setLieunaiss($lieuNaissance) {
        $this->lieuNaissance = $lieuNaissance;
    }
    
         
	//--------Suite accesseurs------------------------
	public function getRegionOrigine() {
        return $this->RegionOrigine;
    }
	public function setRegionOrigine($RegionOrigine) {
        $this->RegionOrigine = $RegionOrigine;
    }
	
	public function getPremlangofficieletud() {
        return $this->premlangofficieletud;
    }
	public function setPremlangofficieletud($premlangofficieletud) {
         $this->premlangofficieletud = $premlangofficieletud;
    }
	
	public function getDeptOrigine() {
        return $this->DeptOrigine;
    }
	public function setDeptOrigine($DeptOrigine) {
         $this->DeptOrigine = $DeptOrigine;
    }
	
	public function getArrondisOrigine() {
        return $this->ArrondisOrigine;
    }
	public function setArrondisOrigine($ArrondisOrigine) {
        $this->ArrondisOrigine = $ArrondisOrigine;
    }
	
//	public function getArrondisNew() {
//        return $this->arrondisNew;
//    }
//	public function setArrondisNew($arrondisNew) {
//         $this->arrondisNew = $arrondisNew;
//    }
//	
	public function getCivilite() {
        return $this->civilite;
    }
	public function setCivilite($civilite) {
        $this->civilite = $civilite;
    }
	
	public function getCnietud() {
        return $this->cnietud;
    }
	public function setCnietud($cnietud) {
       $this->cnietud = $cnietud;
    }
	
	public function getSexeetud() {
        return $this->sexeetud;
    }
	public function setSexeetud($sexeetud) {
         $this->sexeetud = $sexeetud;
    }
	
	public function getNationaliteetud() {
        return $this->nationaliteetud;
    }
	public function setNationaliteetud($nationaliteetud) {
         $this->nationaliteetud = $nationaliteetud;
    }
	
    public function getSituationfamilialetud() {
        return $this->situationfamilialetud;
    }
	public function setSituationfamilialetud($situationfamilialetud) {
        $this->situationfamilialetud = $situationfamilialetud;
    }
	
	public function getNbreenfantetud() {
        return $this->nbreenfantetud;
    }
	public function setNbreenfantetud($nbreenfantetud) {
         $this->nbreenfantetud = $nbreenfantetud;
    }
	
	public function getSituationemploietud() {
        return $this->situationemploietud;
    }
	public function setSituationemploietud($situationemploietud) {
         $this->situationemploietud = $situationemploietud;
    }
	
	public function getHandicape() {
        return $this->handicape;
    }
	public function setHandicape($handicape) {
        $this->handicape = $handicape;
    }
	
	public function getVilleresidenceetudiant() {
        return $this->villeresidenceetudiant;
    }
	public function setVilleresidenceetudiant($villeresidenceetudiant) {
        $this->villeresidenceetudiant = $villeresidenceetudiant;
    }
	
	public function getCodeposte() {
        return $this->codeposte;
    }
	public function setCodeposte($codeposte) {
         $this->codeposte = $codeposte;
    }
	
	public function getTelephone() {
        return $this->telephone;
    }
	public function setTelephone($telephone) {
        $this->telephone = $telephone;
    }
	
	public function getFax() {
        return $this->fax;
    }
	public function setFax($fax) {
         $this->fax = $fax;
    }
	
	public function getEmailetud() {
        return $this->emailetud;
    }
	public function setEmailetud($emailetud) {
         $this->emailetud = $emailetud;
    }
	
	public function getLibelleadresse() {
        return $this->libelleadresse;
    }
	public function setLibelleadresse($libelleadresse) {
         $this->libelleadresse = $libelleadresse;
    }
	
	public function getDiplomeadmission() {
        return $this->diplomeadmission;
    }
	public function setDiplomeadmission($diplomeadmission) {
        $this->diplomeadmission = $diplomeadmission;
    }
	
	public function getAnneeobtensiondiplome() {
        return $this->anneeobtensiondiplome;
    }
	public function setAnneeobtensiondiplome($anneeobtensiondiplome) {
        $this->anneeobtensiondiplome = $anneeobtensiondiplome;
    }
	
	public function getNotediplomeetud() {
        return $this->notediplomeetud;
    }
	public function setNotediplomeetud($notediplomeetud) {
        $this->notediplomeetud = $notediplomeetud;
    }
	
	public function getLieuobtention() {
        return $this->lieuobtention;
    }
	public function setLieuobtention($lieuobtention) {
        $this->lieuobtention = $lieuobtention;
    }
	
	public function getMentiondiplome() {
        return $this->mentiondiplome;
    }
	public function setMentiondiplome($mentiondiplome) {
        $this->mentiondiplome = $mentiondiplome;
    }
	
	public function getIdmodeadmission() {
        return $this->idmodeadmission;
    }
	public function setIdmodeadmission($idmodeadmission) {
        $this->idmodeadmission = $idmodeadmission;
    }
	
	public function getDateinscription() {
        return $this->dateinscription;
    }
	public function setDateinscription($dateinscription) {
        $this->dateinscription = $dateinscription;
    }
//	
//	public function getMoisIns() {
//        return $this->moisIns;
//    }
//	public function setMoisIns($moisIns) {
//        $this->moisIns = $moisIns;
//    }
//	
//	public function getAnneeIns() {
//        return $this->anneeIns;
//    }
//	public function setAnneeIns($anneeIns) {
//        $this->anneeIns = $anneeIns;
//    }
//	
	public function getNompere() {
        return $this->nompere;
    }
	public function setNompere($nompere) {
        $this->nompere = $nompere;
    }
	
	public function getProfessionpere() {
        return $this->professionpere;
    }
	public function setProfessionpere($professionpere) {
        $this->professionpere = $professionpere;
    }
	
    public function getNommere() {
        return $this->nommere;
    }
	public function setNommere($nommere) {
        $this->nommere = $nommere;
    }
	
	public function getProfessionmere() {
        return $this->professionmere;
    }
	public function setProfessionmere($professionmere) {
        $this->professionmere = $professionmere;
    }
	
	public function getCodeposteparent() {
        return $this->codeposteparent;
    }
	public function setCodeposteparent($codeposteparent) {
        $this->codeposteparent = $codeposteparent;
    }
	
	public function getFaxparent() {
        return $this->faxparent;
    }
	public function setFaxparent($faxparent) {
        $this->faxparent = $faxparent;
    }
	
	public function getTelephoneparent() {
        return $this->telephoneparent;
    }
	public function setTelephoneparent($telephoneparent) {
        $this->telephoneparent = $telephoneparent;
    }
	
	public function getLieuderesidenceparent() {
        return $this->lieuderesidenceparent;
    }
	public function setLieuderesidenceparent($lieuderesidenceparent) {
        $this->lieuderesidenceparent = $lieuderesidenceparent;
    }
	
	public function getAdresseparent() {
        return $this->adresseparent;
    }
	public function setAdresseparent($adresseparent) {
        $this->adresseparent = $adresseparent;
    }

    
     public function getSeriediplome() {
        return $this->seriediplome;
    }
	public function setSeriediplome($seriediplome) {
        $this->seriediplome = $seriediplome;
    }
    
//----------------fin accesseurs-------------------------------------------
    
    
//    public function getAdresse() {
//        $model = new Application_Model_AdressesMapper();
//        $adresse = $model->fetchAll('id = ' . $this->getIdadresse());
//        return $adresse[0];
//    }
    
   
//    public function getLocation() {
//        $model = new Application_Model_PropertyLocationMapper();
//        $locations = $model->fetchAll('id = ' . $this->getLocation_id());
//        return $locations[0];
//    }
//
//    public function getDisposition() {
//        $disposition = new Application_Model_DispositionMapper();
//        foreach ($disposition->fetchAll('id = ' . $this->getDisposition_id()) as $disposition_type) {
//            return $disposition_type->getText();
//        }
//    }

//    
//    public function getProperty_build_type() {
//        $m = new Application_Model_PropertyBuildTypeMapper();
//        $res = $m->fetch($this->property_build_id);
//        return $res;
//
//    }

//    public function getTerace() {
//        return str_replace('.0', '', $this->terace);
//    }
//
//    public function setTerace($terace) {
//        $this->terace = str_replace(",", ".",$terace);
//    }
//
//    public function getLoggia() {
//        return str_replace('.0', '', $this->loggia);
//    }
//
//    public function setLoggia($loggia) {
//        $this->loggia = str_replace(",", ".",$loggia);
//    }

 

}

