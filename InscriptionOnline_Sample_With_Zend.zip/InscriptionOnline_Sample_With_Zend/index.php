<?php
 header('location:public/');